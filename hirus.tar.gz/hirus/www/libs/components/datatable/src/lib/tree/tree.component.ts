import {
  Component,
  ContentChildren,
  Input,
  Output,
  QueryList,
  ViewChild,
  ElementRef,
  EventEmitter,
  OnChanges,
  SimpleChanges,
  OnInit
} from '@angular/core';

import {
  ColumnDirective,
  HeaderDirective
} from '../directives/datatable.directive';


@Component({
  selector: 'mn-datatable-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.scss']
})
export class TreeComponent implements OnInit, OnChanges {
  // Variable for calculate height
  @ViewChild('tblBody') tblBody: ElementRef;
  @ViewChild('panelBody') panelBody: ElementRef;

  @Input() dtHeight: number = 0;
  @Input() dtBottomOffset: number = 54;

  // Buttons
  @Input() dtCheckBtn: boolean = false; // Panel Buttons Check
  @Input() dtCheckBtnBlink: boolean = false; // Panel Buttons Check
  @Output() dtCheckBtnClick: EventEmitter<Event> = new EventEmitter();

  @Input() dtMinBtn: boolean = false; // Panel Buttons Minimize
  @Output() dtMinBtnClick: EventEmitter<Event> = new EventEmitter();

  @Input() dtMaxBtn: boolean = false; // Panel Buttons Maximize
  @Output() dtMaxBtnClick: EventEmitter<Event> = new EventEmitter();

  // Header
  @Input() dtHeader: boolean = true;
  @Input() dtLabel: string = ''

  // Toolbar
  @Input() dtToolbarTop: boolean = true; // Panel Toolbar Top
  @Input() dtToolbarBottom: boolean = true; // Panel Toolbar Bottom

  // Footer
  @Input() dtFooter: boolean = false; // Panel Footer

  // Grid Layout
  @Input() dtGridClass: string = '';

  // DnD Group
  @Input() dndGroup: string = '';
  @Input() dndId: string = '';
  @Input() dndKey: string = '';

  // Filtering
  filterText: string = '';
  @Input() filterExclude: string[] = [];

  // Selection
  @Output() selChange: any = new EventEmitter<any>();

  // Column Templates
  @ContentChildren(ColumnDirective) columns: QueryList<ColumnDirective>;

  // Header Templates
  @ContentChildren(HeaderDirective) headers: QueryList<HeaderDirective>;

  // Data
  @Input() data: object[] = [];

  // Local Variable
  curSel: number;
  currExpanded: number[] = [];
  ds: any[] = [];
  isOpen: number[] = [];

  constructor() {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['data']) {
      if (this.data) {
          this.ds = [...this.data]
      }
    }
  }

  ngOnInit() {}

  doSelectRow(row: any) {
    this.curSel = row.id;
    this.selChange.emit(row);
  }

  isExpandChange(id: number) {
    if (!this.currExpanded.find(e => e === id)) {
      this.currExpanded.push(id);
    } else {
      this.currExpanded.splice(this.currExpanded.indexOf(id), 1);
    }
  }
}
