import { Params } from '@angular/router';

export interface DropdownModel {
  label: string;
  link?: string;
  query?: Params;
  external?: boolean;
}
