import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// Handlers & Interceptors
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ApiErrorHandler } from '@mn/handlers';
import { ApiInterceptor } from '@mn/interceptors';

import { FontAwesomeModule, FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { fas } from '@fortawesome/free-solid-svg-icons';
import { far } from '@fortawesome/free-regular-svg-icons';
import { fab } from '@fortawesome/free-brands-svg-icons';

import { ToastrModule } from 'ngx-toastr';

import { AppRouting } from './app.routing';
import { MnStoreModule } from '@mn/store';

import { LayoutModule } from './common/layout/layout.module';
import { BreadcrumbModule } from './common/breadcrumb/breadcrumb.module';

import { SidenavModule } from '@mn/components/sidenav';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,

    HttpClientModule,

    FontAwesomeModule,

    ToastrModule.forRoot(),

    LayoutModule,
    SidenavModule,
    BreadcrumbModule,

    AppRouting,

    MnStoreModule
  ],
  providers: [{
    provide: ErrorHandler,
    useClass: ApiErrorHandler
  },{
    provide: HTTP_INTERCEPTORS,
    useClass: ApiInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor(library: FaIconLibrary) {
    library.addIconPacks(fas, far, fab);
  }
}
