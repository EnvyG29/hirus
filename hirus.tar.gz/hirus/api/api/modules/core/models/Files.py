# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy.dialects import postgresql as psql

from ....lib.Db import TblBase

class Files(TblBase):
    __tablename__ = 'files'
    __table_args__ = {'schema': 'core'}

    cf_meta = Column(psql.JSONB(), nullable=False, default='{}')
