# -*- coding: utf-8 -*-

from fastapi import HTTPException

class RaiseEx(HTTPException):
    def __init__(self, code: int, msg: str):
        super().__init__(status_code=code, detail=msg)
