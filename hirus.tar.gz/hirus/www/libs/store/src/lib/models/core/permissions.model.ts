import { ApiResponse } from '@mn/store';

import { ModuleCtl } from "@mn/store";

export interface PermItem {
  id?: number;
  cp_name: string;
  cp_desc: string;
  cp_data?: ModuleCtl[];
}

export interface PermResponse extends ApiResponse {
  data: PermItem[];
}
