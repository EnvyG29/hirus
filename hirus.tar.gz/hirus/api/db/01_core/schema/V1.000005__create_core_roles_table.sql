------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Create: Date: 2018-12-07
-- Desc: Company Roles
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."roles_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."roles" (
   "id"                       INTEGER NOT NULL DEFAULT nextval('core.roles_id_seq'::REGCLASS)
  ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  ,"cr_cp_id"                 INTEGER NOT NULL REFERENCES "core"."projects" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
  ,"cr_lkey"                  INTEGER NOT NULL DEFAULT 1
  ,"cr_rkey"                  INTEGER NOT NULL DEFAULT 2
  ,"cr_lvl"                   INTEGER NOT NULL DEFAULT 1
  ,"cr_meta"                  JSONB NOT NULL DEFAULT '{}'
  ,PRIMARY KEY ("id")
);
ALTER SEQUENCE "core"."roles_id_seq" OWNED BY "core"."roles"."id";

-- Comment
COMMENT ON TABLE "core"."roles" IS 'Company Roles';
COMMENT ON COLUMN "core"."roles"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."roles"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."roles"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."roles"."cr_cp_id" IS 'Link to core.projects table (Nested Sets multitree)';
COMMENT ON COLUMN "core"."roles"."cr_lkey" IS 'Record left key (Nested Sets)';
COMMENT ON COLUMN "core"."roles"."cr_rkey" IS 'Record right key (Nested Sets)';
COMMENT ON COLUMN "core"."roles"."cr_lvl" IS 'Record level (Nested Sets)';
COMMENT ON COLUMN "core"."roles"."cr_meta" IS 'Role Info';

/*
{
  "name": "Root",
  "desc": "Root Tree",
  "icon": {
    "type": "fa",
    "val": ["fas", "users"]
  }
}
*/