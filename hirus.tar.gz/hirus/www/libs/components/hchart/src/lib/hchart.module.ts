import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { HchartComponent as Hchart} from './hchart.component';

@NgModule({
  imports: [
    CommonModule,

    FontAwesomeModule
  ],
  exports: [
    Hchart
  ],
  declarations: [
    Hchart
  ]
})
export class HchartModule {}
