export interface UserTel {
  type: string;
  tel: string;
  default: boolean;
}

export interface UserEmail {
  type: string;
  email: string;
  default: boolean;
}

export interface UserOauth {
  type: string;
  enabled: boolean;
}

export interface UserProfile {
  id?: number;
  create_at?: string;
  update_at?: string;
  cu_profile: {
    balance: number,
    profile: {
      name: {
        first?: string;
        sur?: string;
        last?: string;
      };
      oauth?: UserOauth[];
      aditional: {
        tel?: UserTel[];
        email?: UserEmail[];
      };
    };
    credentials: {
      tel: string;
      email: string;
      login: string;
    };
  };
  cu_padm: boolean;
  cu_enable: boolean;
}
