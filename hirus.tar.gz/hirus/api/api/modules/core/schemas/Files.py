# -*- coding: utf-8 -*-

from typing import List
from pydantic import BaseModel

from ....common.schema.TblBase import TblBase
from ....common.schema.Response import SuccessResponse

class FileMeta(BaseModel):
    orig_name: str
    mime: str
    path: str

class File(TblBase):
    cf_meta: FileMeta

    class Config:
        orm_mode = True

class Files(SuccessResponse):
    data: File

    class Config:
        arbitrary_types_allowed = True
