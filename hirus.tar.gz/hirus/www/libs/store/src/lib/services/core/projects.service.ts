import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment as env } from '@mn/environments';

import {
  ProjAddEditPayload,
  ProjResponse
} from '../../models';

@Injectable({
  providedIn: 'root'
})
export class ProjectsService {
  constructor(
    private http: HttpClient
  ) {}

  getProjects() {
    return this.http.get<ProjResponse>(`${env.api}/core/projects/`);
  }

  addProject(payload: ProjAddEditPayload) {
    return this.http.post<ProjResponse>(`${env.api}/core/projects/`, payload);
  }

  editProject(payload: ProjAddEditPayload) {
    return this.http.put<ProjResponse>(`${env.api}/core/projects/`, payload);
  }

  deleteProject(rid: number) {
    return this.http.delete<ProjResponse>(`${env.api}/core/projects/${rid}/`);
  }
}
