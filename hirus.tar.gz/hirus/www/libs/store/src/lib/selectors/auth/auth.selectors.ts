import { createSelector, createFeatureSelector } from '@ngrx/store';

import { AuthState } from '../../models';
import { authNode } from '../../reducers';

export const authFeatures = createFeatureSelector<AuthState>(authNode);

export const isAuthHandling = createSelector(
  authFeatures,
  (state: AuthState): boolean => state.handling
)

export const isLoggedIn = createSelector(
  authFeatures,
  (state: AuthState): boolean => state.isLoggedIn
)

export const getUserProfile = createSelector(
  authFeatures,
  (state: AuthState): any => state.user
)
