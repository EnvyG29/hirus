import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';

@Component({
  selector: 'mn-panel-legacy',
  templateUrl: './panel-legacy.component.html',
  styleUrls: ['./panel-legacy.component.scss']
})
export class PanelLegacyComponent implements OnInit {
  @Input() pCheckBtn: boolean = true; // Panel Buttons Check
  @Input() pCheckBtnBlink: boolean = false; // Panel Buttons Check Blink
  @Input() pMinBtn: boolean = true; // Panel Buttons Minimize
  @Input() pMaxBtn: boolean = true; // Panel Buttons Maximize
  @Input() pCloseBtn: boolean = true; // Panel Buttons Close
  @Input() pToolbarTop: boolean = true; // Panel Toolbar Top
  @Input() pToolbarBottom: boolean = true; // Panel Toolbar Bottom
  @Input() pFooter: boolean = false; // Panel Footer
  @Input() pLabel: string = ''

  @Output() onCheckBtnClick: EventEmitter<Event> = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }
}
