import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment as env } from '@mn/environments';

import {
  RoleAddEditPayload,
  RoleResponse
} from '../../models';

@Injectable({
  providedIn: 'root'
})
export class RolesService {
  constructor(
    private http: HttpClient
  ) {}

  getRoles(pid: number) {
    return this.http.get<RoleResponse>(`${env.api}/core/roles/${pid}/`);
  }

  addRoles(payload: RoleAddEditPayload) {
    return this.http.post<RoleResponse>(`${env.api}/core/roles/`, payload);
  }

  editRoles(pid: number, payload: RoleAddEditPayload) {
    return this.http.put<RoleResponse>(`${env.api}/core/roles/${pid}/`, payload);
  }

  deleteRoles(pid: number, rid: number) {
    return this.http.delete<RoleResponse>(`${env.api}/core/roles/${pid}/${rid}/`);
  }
}
