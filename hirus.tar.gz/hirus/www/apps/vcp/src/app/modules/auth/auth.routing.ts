import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthComponent } from './auth.component';
import { LoginComponent as AuthLogin } from './login/login.component';
import { RegisterComponent as AuthRegister } from './register/register.component';
import { ForgotComponent as AuthForgot } from './forgot/forgot.component';
import { ActivateComponent as AuthActivate } from './activate/activate.component';

export const routes: Routes = [
  { path: '', component: AuthComponent,
    children: [
      { path: '', redirectTo: 'login', pathMatch: 'full' },
      { path: 'login', component: AuthLogin },
      { path: 'register', component: AuthRegister },
      { path: 'forgot', component: AuthForgot },
      { path: 'activate', component: AuthActivate }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRouting {}
