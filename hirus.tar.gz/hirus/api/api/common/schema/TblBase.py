# -*- coding: utf-8 -*-

from typing import Optional
from datetime import datetime
from pydantic import BaseModel
from pydantic import Field

class TblBase(BaseModel):
    id: Optional[int] = Field(None, description='ID Primary Key')
    create_at: Optional[datetime] = Field(None, description='Create record (datetime)')
    update_at: Optional[datetime] = Field(None, description='Update record (datetime)')
