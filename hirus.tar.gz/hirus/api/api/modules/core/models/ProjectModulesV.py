# -*- coding: utf-8 -*-

from sqlalchemy import Column

from sqlalchemy.dialects import postgresql as psql

from ....lib.Db import Base

class ProjectModulesV(Base):
    __tablename__ = 'project_modules_v'
    __table_args__ = {'schema': 'core'}

    id = Column(psql.INTEGER, primary_key=True)
    cm_meta = Column(psql.JSONB(), nullable=False, default='{}')
    cp_id = Column(psql.INTEGER, nullable=False)
    cpm_id = Column(psql.INTEGER, nullable=False)
    cpm_cp_id = Column(psql.INTEGER, nullable=False)
    cpm_cm_id = Column(psql.INTEGER, nullable=False)
    enabled = Column(psql.BOOLEAN)
