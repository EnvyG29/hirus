import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vcp-dash-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {

  constructor(
  ) { }

  ngOnInit(): void {
  }
}
