import logging

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models.Files import Files as mFiles

log = logging.getLogger('api.core.service.upload')

async def add_file(cf_meta: dict, sess: AsyncSession):
    i_file = mFiles(
        cf_meta=cf_meta
    )
    sess.add(i_file)
    await sess.commit()

    t_data = await sess.execute(
        select(mFiles)
        .filter(
            mFiles.id == i_file.id
        )
    )

    c_file = t_data.scalars().first()
    return c_file

