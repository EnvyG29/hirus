import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment as env } from '@mn/environments';

import {
  WbCols,
  WbBadges,
  WbPrio,
  WbConfigResponse,
} from '../../models';

@Injectable({
  providedIn: 'root'
})
export class WbService {
  constructor(
    private http: HttpClient
  ) {}

  getWbConfig(pid: number) {
    return this.http.get<WbConfigResponse>(`${env.api}/kanban/wb//${pid}/`);
  }

  applyWbColConfig(wid: number, cols: WbCols[]) {
    return this.http.put<WbConfigResponse>(`${env.api}/kanban/wb/cols/`, {wid, cols});
  }

  applyWbBadgeConfig(wid: number, badges: WbBadges[]) {
    return this.http.put<WbConfigResponse>(`${env.api}/kanban/wb/badges/`, {wid, badges});
  }

  applyWbPrioConfig(wid: number, prio: WbPrio[]) {
    return this.http.put<WbConfigResponse>(`${env.api}/kanban/wb/prio/`, {wid, prio});
  }
}
