import { createAction, props } from '@ngrx/store';

import {
  ModulesResponse,
  ModulesChangePayload
} from '../../models';

export const GetModules = createAction(
  '[App/Core] Get Platform Modules'
)

export const GetModulesSuccess = createAction(
  '[Api/Core] Get Platform Modules Success',
  props<{ payload: ModulesResponse }>()
)

export const ProjectModulesChange = createAction(
  '[App/Core] Cange Project Module Start',
  props<{ payload: ModulesChangePayload }>()
)

export const modulesActions = {
  GetModules,
  GetModulesSuccess,
  ProjectModulesChange
}
