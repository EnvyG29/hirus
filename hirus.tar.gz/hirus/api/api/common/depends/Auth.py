# -*- coding: utf-8 -*-

import jwt
import logging

from datetime import datetime
from datetime import timedelta

from fastapi import Cookie

from starlette.datastructures import Headers
from starlette.requests import Request
from starlette.responses import JSONResponse

from pydantic import ValidationError

from ..schema.TokenData import TokenData
from ..schema.Response import error_response
from ..schema.Response import Errors
from ..schema.Response import ErrorResponseException

from cfg.api import config as cfg

log = logging.getLogger('api.common.auth')

def assign_session(resp: JSONResponse, user) -> JSONResponse:
    now = datetime.utcnow()

    """ Access Token Create """
    access_token = TokenData(user_id=user.id).dict()
    access_token.update(is_padm=user.cu_padm, iat=now, exp=now + timedelta(seconds=cfg.ACCESS_TOKEN_AGE))
    access_token_sign = jwt.encode(access_token, cfg.JWT_SECRET_KEY, algorithm=cfg.JWT_ALGO)

    """ Refresh Token Create """
    refresh_token = TokenData(user_id=user.id).dict()
    refresh_token.update(is_padm=user.cu_padm, iat=now, exp=now + timedelta(seconds=cfg.REFRESH_TOKEN_AGE))
    refresh_token_sign = jwt.encode(refresh_token, cfg.JWT_SECRET_KEY, algorithm=cfg.JWT_ALGO)

    resp.set_cookie(
        'access', access_token_sign, max_age=cfg.ACCESS_TOKEN_AGE, secure=cfg.SECURE_COOKIES, httponly=True
    )

    resp.set_cookie(
        'refresh', refresh_token_sign, max_age=cfg.REFRESH_TOKEN_AGE, secure=cfg.SECURE_COOKIES, httponly=True
    )

    return resp

# JWT Manipulation
def parse_token(token: str) -> TokenData:
    if not token:
        raise ValueError('Token not found')

    try:
        parsed = jwt.decode(token, cfg.JWT_SECRET_KEY, algorithms=cfg.JWT_ALGO)
        log.debug('token => {}'.format(parsed))

        return TokenData(**parsed)

    except jwt.ExpiredSignatureError:
        raise ValueError('Token Expired')

    except jwt.InvalidSignatureError:
        raise ValueError('Token Wrong')

    except jwt.DecodeError:
        raise ValueError('Token Invalid')

    except ValidationError:
        raise ValueError('Token Invalid Data')

async def _auth(headers: Headers, cookie: str) -> TokenData:
    return parse_token(cookie)

async def auth(req: Request, cookie: str = Cookie(None, alias='access')) -> TokenData:
    try:
        return await _auth(req.headers, cookie)

    except ValueError as e:
        raise ErrorResponseException(error_response(401, Errors.auth, err_data=str(e)))
