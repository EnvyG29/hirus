# -*- coding: utf-8 -*-

from socketio import AsyncServer
from socketio import AsyncRedisManager
from socketio import ASGIApp

from .sns.Server import ServerIO

mgr = AsyncRedisManager(
    url='redis://redis:6379/0',
    channel='vcp'
)
sio = AsyncServer(
    async_mode='asgi',
    cors_allowed_origins='*',
    client_manager=mgr,
    cors_credentials=True
)

sio.register_namespace(ServerIO('/vcp'))
asgi = ASGIApp(sio)
