import { ApiResponse } from '@mn/store';

export interface ModuleCtl {
  group: string;
  ctl: string;
  desc: string;
}

export interface Module {
  id: number;
  cm_meta: {
    name: string;
    desc: string;
    mode: 'dev' | 'test' | 'prod';
    type: 'public' | 'private';
    icon: {
      type: 'fa' | 'img';
      val: string[] | string;
    };
    menu?: any;
    ctl?: ModuleCtl[];
    active: boolean;
    managed: boolean;
  }
  cp_id: number;
  cpm_id: number;
  cpm_cp_id: number;
  cpm_cm_id: number;
  enabled: boolean;
}

export interface ModulesChangePayload {
  mid: number;
  status: boolean;
}

export interface ModulesResponse extends ApiResponse {
  data: Module[];
}

/*
{
    "name": "Test",
    "desc": "Test Module",
    "mode": "dev|test|prod",
    "type": "public|private",
    "icon": {
        "type": "fa",
        "val": ['fas', 'box-open']
    },
    "menu": {
        "label": "Test 1",
        "url": "/test",
        "icon": {
            "type": "fa",
            "val": ['fab', 'google']
        },
        child?: []
    },
    "ctl": [{
        "name": "",
        "desc": "",
        "mask": "1-15"
    }],
    "active": "true|false",
    "managed": "true|false"
}
*/
