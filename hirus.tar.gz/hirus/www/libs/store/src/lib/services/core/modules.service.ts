import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment as env } from '@mn/environments';

import { ModulesResponse } from '../../models';

@Injectable({
  providedIn: 'root'
})
export class ModulesService {
  constructor(
    private http: HttpClient
  ) {}

  getModules(pid: number) {
    return this.http.get<ModulesResponse>(`${env.api}/core/modules/${pid}/`);
  }

  prModChange(pid: number, mid: number, status: boolean) {
    return this.http.put<ModulesResponse>(`${env.api}/core/modules/`, {pid, mid, status});
  }
}
