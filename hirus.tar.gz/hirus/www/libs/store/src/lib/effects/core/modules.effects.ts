import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { mergeMap, map, withLatestFrom, tap  } from 'rxjs/operators';

import { CoreState } from '@mn/store';
import { modulesActions } from '@mn/store';
import { getCurrProj } from '@mn/store';

import {
  ModulesService
} from '@mn/store';

@Injectable({
  providedIn: 'root'
})
export class ModulesEffects {
  constructor(
    private actions$: Actions,
    private mService: ModulesService,
    private store: Store<CoreState>
  ) {
  }

  getModules$ = createEffect(() => this.actions$.pipe(
      ofType(modulesActions.GetModules),
      withLatestFrom(this.store.select(getCurrProj)),
      mergeMap(([action, pid]) => this.mService.getModules(pid)
        .pipe(
          map(res => {
            return modulesActions.GetModulesSuccess({payload: res});
          })
        )
      )
  ));

  prModulesChange$ = createEffect(() => this.actions$.pipe(
      ofType(modulesActions.ProjectModulesChange),
      withLatestFrom(this.store.select(getCurrProj)),
      mergeMap(([action, pid]) => this.mService.prModChange(pid, action.payload.mid, action.payload.status)
        .pipe(
          map(res => {
            return modulesActions.GetModulesSuccess({payload: res});
          })
        )
      )
  ));
}
