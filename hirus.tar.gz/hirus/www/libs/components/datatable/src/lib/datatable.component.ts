import {
  Component,
  ContentChildren,
  Input,
  Output,
  QueryList,
  ViewChild,
  ElementRef,
  EventEmitter,
  OnChanges,
  SimpleChanges,
  OnInit
} from '@angular/core';

import {
  ColumnDirective,
  HeaderDirective
} from './directives/datatable.directive';

@Component({
  selector: 'mn-datatable',
  templateUrl: './datatable.component.html',
  styleUrls: ['./datatable.component.scss']
})
export class DatatableComponent implements OnInit, OnChanges {
  // Variable for calculate height
  @ViewChild('tblBody') tblBody: ElementRef;
  @ViewChild('panelBody') panelBody: ElementRef;

  @Input() dtHeight: number = 0;
  @Input() dtBottomOffset: number = 54;

  // Datatable Panel Config
  // Type
  @Input() dtType: string = 'legacy';

  // Buttons
  @Input() dtCheckBtn: boolean = false; // Panel Buttons Check
  @Input() dtCheckBtnBlink: boolean = false; // Panel Buttons Check
  @Output() dtCheckBtnClick: EventEmitter<Event> = new EventEmitter();

  @Input() dtMinBtn: boolean = false; // Panel Buttons Minimize
  @Output() dtMinBtnClick: EventEmitter<Event> = new EventEmitter();

  @Input() dtMaxBtn: boolean = false; // Panel Buttons Maximize
  @Output() dtMaxBtnClick: EventEmitter<Event> = new EventEmitter();

  // Header
  @Input() dtHeader: boolean = true;
  @Input() dtLabel: string = ''

  // Toolbar
  @Input() dtToolbarTop: boolean = true; // Panel Toolbar Top
  @Input() dtToolbarBottom: boolean = true; // Panel Toolbar Bottom

  // Footer
  @Input() dtFooter: boolean = false; // Panel Footer

  // Grouping
  @Input() doGroup: boolean = false;
  @Input() doHideGroupCol: boolean = false;
  @Input() doGroupCol: string = '';

  // Grid Layout
  @Input() dtGridClass: string = '';

  // DnD Group
  @Input() dndGroup: string = '';
  @Input() dndId: string = '';
  @Input() dndKey: string = '';

  // Filtering
  filterText: string = '';
  @Input() filterExclude: string[] = [];

  // Selection
  @Output() selChange: any = new EventEmitter<any>();

  // Column Templates
  @ContentChildren(ColumnDirective) columns: QueryList<ColumnDirective>;

  // Header Templates
  @ContentChildren(HeaderDirective) headers: QueryList<HeaderDirective>;

  // Data
  @Input() data: object[] = [];

  // Local Variable
  curSel: any;
  currGroup: any;
  ds: any[] = [];

  constructor() {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['data']) {
      if (this.data) {
        if (this.doGroup) {
          this.ds = [];

          this.currGroup = new Set(
            this.data.map((row: any) => row[this.doGroupCol])
          );

          this.currGroup.forEach( (g: any) => this.ds.push({
            name: g,
            collapsed: false,
            values: this.data.filter((r: any) => r[this.doGroupCol] === g)
          }));
        } else {
          this.ds = [...this.data]
        }
      }
    }
  }

  ngOnInit() {}

  doSearchChange(evt: any) {
    this.filterText = evt.target.value;
  }

  doSelectRow(row: any) {
    this.curSel = row;
    this.selChange.emit(row);
  }

  onCollapseGroup(group: string) {
    let idx = this.ds.findIndex(r => r.name === group);
    this.ds[idx].collapsed = !this.ds[idx].collapsed;
  }
}
