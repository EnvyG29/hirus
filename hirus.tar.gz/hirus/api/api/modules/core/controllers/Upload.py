# -*- coding: utf-8 -*-

import magic
import logging

from uuid import uuid4

from fastapi import Depends
from fastapi import File
from fastapi import Form
from fastapi import UploadFile
from fastapi.encoders import jsonable_encoder

from starlette.responses import JSONResponse

from sqlalchemy.ext.asyncio import AsyncSession
from ....common.depends.DbSession import get_db

from ....common.depends.Auth import auth as dAuth
from ....common.schema.Response import ErrorResponse as sErrorResponse

from ..schemas.Files import Files as sFiles

from ..services.Upload import add_file

from .router import router

from cfg.api import config as cfg

log = logging.getLogger('api.core.controller.upload')
mime = magic.Magic(mime=True)

@router.post(
    '/upload/',
    response_model=sFiles,
    responses={
        200: {'model': sFiles},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Upload']
)
async def upload_post(file: UploadFile = File(...), ftype: str = Form(...), mn_sess: AsyncSession = Depends(get_db)):
    log.warning('File => {}'.format(file.filename))
    log.warning('Type => {}'.format(dir(file)))

    f_path = '{}/{}'.format(cfg.FILES_DIR[ftype],str(uuid4()))

    f_cnt = await file.read()
    f_mime = mime.from_buffer(f_cnt)
    log.warning('File Mime => {}'.format(f_mime))

    cf_meta = {
        'orig_name': str(file.filename),
        'mime': str(f_mime),
        'path': str(f_path)
    }

    with open(f_path, 'wb') as f:
        f.write(f_cnt)
        f.close()

    i_file = await add_file(cf_meta=cf_meta, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sFiles(data=i_file)))
