# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy import ForeignKey
from sqlalchemy.dialects import postgresql as psql

from .Projects import Projects
from .Users import Users

from ....lib.Db import TblBase

class AclMatrix(TblBase):
    __tablename__ = 'acl_matrix'
    __table_args__ = {'schema': 'core'}

    cam_cp_id = Column(psql.INTEGER, ForeignKey(Projects.id), nullable=False)
    cam_cu_id = Column(psql.INTEGER, ForeignKey(Users.id), nullable=False)
    cam_matrix = Column(psql.JSONB(), nullable=False, default='{}')
