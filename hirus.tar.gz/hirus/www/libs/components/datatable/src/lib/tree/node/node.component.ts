import {
  Component,
  EventEmitter,
  ContentChildren,
  Input,
  Output,
  OnInit
} from '@angular/core';

import { animate, style, transition, trigger } from "@angular/animations";


@Component({
  selector: 'mn-datatable-tree-node',
  templateUrl: './node.component.html',
  styleUrls: ['./node.component.scss'],
  animations: [
    trigger('inout', [
      transition(':enter', [
        style({ height: 0, overflow: 'hidden' }),
        animate('125ms', style({ height: '*' })),
      ]),
      transition(':leave', [
        style({ height: '*', overflow: 'hidden' }),
        animate('125ms', style({ height: 0 }))
      ])
    ])
  ]
})
export class NodeComponent implements OnInit {
  @Input() item: any[] = [];
  @Input() columns: any;
  @Input() dtGridClass: any;

  // Selection
  @Output() selChange: any = new EventEmitter<any>();
  @Output() isExpandChange: any = new EventEmitter<any>();

  @Input() curSel: number;
  @Input() currExpanded: number[] = [];

  constructor(
  ) { }

  ngOnInit(): void {
  }

  doSelectRow(row: any) {
    this.selChange.emit(row);
  }

  isExpand(id: number) {
    return !!this.currExpanded.find(e => e === id);
  }

  doExpandChange(id: number) {
    this.isExpandChange.emit(id);
  }

  calcPadding(lvl: number) {
    return 'padding-left:' + lvl + 'rem;';
  }
}
