import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vcp-auth-activate',
  templateUrl: './activate.component.html',
  styleUrls: ['./activate.component.scss']
})
export class ActivateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
