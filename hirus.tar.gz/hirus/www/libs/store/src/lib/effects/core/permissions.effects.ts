import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { mergeMap, map, withLatestFrom, tap  } from 'rxjs/operators';

import { CoreState } from '@mn/store';
import { permissionsActions } from '@mn/store';
import { getCurrProj } from '@mn/store';

import {
  PermissionsService
} from '@mn/store';

@Injectable({
  providedIn: 'root'
})
export class PermissionsEffects {
  constructor(
    private actions$: Actions,
    private pService: PermissionsService,
    private store: Store<CoreState>
  ) {
  }

  getPermissions$ = createEffect(() => this.actions$.pipe(
    ofType(permissionsActions.GetPermissions),
    withLatestFrom(this.store.select(getCurrProj)),
    mergeMap(([action, pid]) => this.pService.getPermissions(pid)
      .pipe(
        map(res => {
          return permissionsActions.GetPermissionsSuccess({payload: res});
        })
      )
    )
  ));
}
