import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';

import {
  AppState,
  SideNav,
  authActions,
  isLoggedIn,
  LsService
} from '@mn/store';

import { SidenavItem } from '@mn/components/sidenav';

@Component({
  selector: 'vcp-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  sideNav: SidenavItem[] = SideNav;

  /*
  export interface SidenavItem {
    icon: {
      type: string;
      val: string;
    };
    label: string;
    link?: string;
    child?: SidenavItem[];
    isOpen: boolean;
    disabled: boolean;
  }

  */

  iaAuth: boolean = true;
  isLoggedIn$: Observable<boolean> = this.store.pipe(select(isLoggedIn));
  auth: any;

  constructor(
    private store: Store<AppState>,
    private lService: LsService
  ) {
    this.auth = this.lService.getItem('auth')

    if ( this.auth && this.auth.id ) {
      this.store.dispatch(authActions.SignInResore({ payload: this.auth }));
    }
  }

  ngOnInit(): void {
  }

  ngOnDestroy(): void {
    // this.ws.wsLeave();
  }
}
