# -*- coding: utf-8 -*-

from os import path

from datetime import timedelta
from datetime import time

from envreader import EnvReader
from envreader import Field
from envreader import EnvTransformError
from envreader import EnvMissingError

class Config(EnvReader):
    # Api Configuration
    API_PREFIX: str = Field('/api', description="Api server prefix")
    API_VER: str = Field('2', description="Api version")

    # Database connection
    SA_URL: str = Field(..., description="SqlAlchemy database mn URL")
    LSTN_MEGA_DSN: str = Field(..., description="SqlAlchemy database mn URL")

    ACCT_CHAN = [
        {'chan': 'dsp', 'name': ['SbAcc', 'RkAcc']}
    ]

    # Application configure
    API_HOST: str = Field('localhost', description='Api server bindings')
    API_PORT: str = Field('5000', description='Api server port')

    # SECURE_COOKIES: bool = Field(True, description="Create secured cookies")
    SECURE_COOKIES: bool = Field(True, description="Create secured cookies")

    JWT_ALGO: str = Field("HS256", description="Algo to sign jwt secrets")
    JWT_SECRET_KEY: str = Field(..., description="Key to sign jwt secrets")

    # Token configuration
    ACCESS_TOKEN_SIZE: int = Field(64, description="Access token size in bytes for token_urlsafe function")
    REFRESH_TOKEN_SIZE: int = Field(64, description="Refresh token size in bytes for token_urlsafe function")

    ACCESS_TOKEN_AGE: int = Field(86400, description="Auth token age in seconds")
    REFRESH_TOKEN_AGE: int = Field(259200, description="Refresh token age in seconds")
    # ACCESS_TOKEN_AGE: int = Field(60 * 6, description="Auth token age in seconds")
    # REFRESH_TOKEN_AGE: int = Field(60 * 60 * 1, description="Refresh token age in seconds")

    WS_TOKEN_AGE: int = Field(20, description="Websoket token age in seconds")
    DEBUG_RESPONSES: bool = Field(True, description="Enable Response Debug")

try:
    config = Config()

except EnvTransformError as e:
    print('Malformed environment parameter {}!'.format(e.field))
    print('Settings help:\n' + Config(populate=False).help())
    print('Committing suicide...')

except EnvMissingError as e:
    print('Configuration key {} was not found in env!'.format(e.args[0]))
    print('Settings help:\n' + Config(populate=False).help())
    print('Committing suicide...')
