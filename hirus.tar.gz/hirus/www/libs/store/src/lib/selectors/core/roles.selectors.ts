import { createSelector, createFeatureSelector } from '@ngrx/store';

import {
  CoreState,
  RoleItem
} from '../../models';

import { coreNode } from '../../reducers';

export const rolesFeatures = createFeatureSelector<CoreState>(coreNode);

export const getAllRoles = createSelector(
  rolesFeatures,
  (state: CoreState): RoleItem => state.roles
)
