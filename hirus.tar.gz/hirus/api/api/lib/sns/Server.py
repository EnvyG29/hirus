# -*- coding: utf-8 -*-

import logging

from socketio.asyncio_namespace import AsyncNamespace
from urllib.parse import parse_qs

from api.common.depends.Auth import parse_token

log = logging.getLogger('lib.ws')

class ServerIO(AsyncNamespace):
    async def on_connect(self, sid, env):
        #q_token = parse_qs(env['QUERY_STRING'])['token'][0]
        #log.info('Env => {}'.format(env))

        #try:
        #    token = parse_token(q_token)
        #    log.info('Client Connect Token => {}'.format(token))
        #
        #    if not token.ws:
        #        raise ValueError("Token ok but it is not for websocket!")
        #
        #    await self.emit('vcp', {'event': 'connected', 'payload': {'client': sid, 'data': 'connected'}})
        #
        # except ValueError as e:
        #    await self.on_disconnect(sid)

        await self.emit('vcp', {'event': 'connected', 'payload': {'client': sid, 'data': 'connected'}})

    async def on_disconnect(self, sid):
        log.debug('Client Disconnect sid {}'.format(sid))
        await self.emit('vcp', {'event': 'connected', 'payload': {'client': sid, 'data': 'disconnected'}})

    async def on_job(self, sid, data):
        log.debug('Client job sid {}'.format(sid))
        log.debug('Client job data {}'.format(data))

        await self.emit(
            'job',
            {'event': 'vcp.core.Test123', 'queue': 'vcp.tasks', 'payload': {'data': {}}},
            room=sid
        )
