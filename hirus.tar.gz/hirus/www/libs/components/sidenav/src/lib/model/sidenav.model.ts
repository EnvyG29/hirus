export interface Sidenav {
  menu: SidenavItem[];
}

export interface SidenavItem {
  icon: {
    type: string;
    val: string[] | string;
  };
  label: string;
  link?: string;
  child?: SidenavItem[];
  isOpen: boolean;
  disabled: boolean;
}
