export * from './lib/services/window.service';

export * from './lib/window.module';
