import { Directive, ContentChild, Input, TemplateRef, OnInit } from '@angular/core';

@Directive({
  selector: 'dt-col'
})
export class ColumnDirective implements OnInit {
  @Input() key: string;
  @Input() header: string;
  @Input() hasProgressBar: boolean;
  @Input() dtColClass: string;

  @ContentChild(TemplateRef, {static: true}) template: any;

  ngOnInit() {
  }
}

@Directive({
  selector: 'dt-header'
})
export class HeaderDirective implements OnInit {
  @Input() dhColClass: string;
  @Input() dhName: string;
  @ContentChild(TemplateRef, {static: true}) template: any;
  ngOnInit() {
  }
}
