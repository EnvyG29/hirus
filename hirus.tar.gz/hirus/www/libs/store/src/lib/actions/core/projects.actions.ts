import { createAction, props } from '@ngrx/store';

import {
  ProjResponse,
  ProjAddEditPayload
} from '../../models';

export const GetProjects = createAction(
  '[App/Core] Get Projects Tree'
)

export const GetProjectsSuccess = createAction(
  '[Api/Core] Get Project Tree Success',
  props<{ payload: ProjResponse }>()
)

export const AddProject = createAction(
  '[App/Core] Add Project',
  props<{ payload: ProjAddEditPayload }>()
)

export const EditProject = createAction(
  '[App/Core] Edit Project',
  props<{ payload: ProjAddEditPayload }>()
)

export const DeleteProject = createAction(
  '[App/Core] Delete Project',
  props<{ rid: number }>()
)

export const projectActions = {
  GetProjects,
  GetProjectsSuccess,
  AddProject,
  EditProject,
  DeleteProject
}
