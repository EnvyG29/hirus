------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Create: Date: 2019-01-21
-- Desc: files
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."files_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."files" (
     "id"                       INTEGER NOT NULL DEFAULT nextval('core.files_id_seq'::REGCLASS)
    ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"cf_meta"                  JSONB NOT NULL DEFAULT '{}'
    ,PRIMARY KEY ("id")
);
ALTER SEQUENCE "core"."files_id_seq" OWNED BY "core"."files"."id";