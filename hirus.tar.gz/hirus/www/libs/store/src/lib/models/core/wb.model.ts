import { ApiResponse } from '@mn/store';

export interface WbCols {
  name: string;
  tag: string;
  max: number;
  order: number;
  protected: boolean;
}

export interface WbBadges {
  text: string;
  tag: string;
  protected: boolean;
}

export interface WbPrio {
  text: string;
  tag: string;
  color: string;
  protected: boolean;
}

export interface WbConfig {
  id: number;
  kw_cp_id: number;
  kw_cols: WbCols[];
  kw_badge: WbBadges[];
  kw_prio: WbPrio[];
}

export interface WbConfigResponse extends ApiResponse {
  data: WbConfig;
}

export interface WbPrioColorItem {
  color: string;
  desc: string;
  c_class: string;
  s_class: string;
}

export const WbPrioColor: WbPrioColorItem[] = [
  { color: 'red', desc: 'Red', c_class: 'flag-red', s_class: 'bg-red-500 text-white  font-semibold tracking-wider' },
  { color: 'amber', desc: 'Amber', c_class: 'flag-amber', s_class: 'bg-amber-500 text-white  font-semibold tracking-wider' },
  { color: 'lime', desc: 'Lime', c_class: 'flag-lime', s_class: 'bg-lime-500 text-white  font-semibold tracking-wider' },
  { color: 'emerald', desc: 'Emerald', c_class: 'flag-emerald', s_class: 'bg-emerald-500 text-white  font-semibold tracking-wider' },
  { color: 'cyan', desc: 'Cyan', c_class: 'flag-cyan', s_class: 'bg-cyan-500 text-white  font-semibold tracking-wider' },
  { color: 'blue', desc: 'Blue', c_class: 'flag-blue', s_class: 'bg-blue-500 text-white  font-semibold tracking-wider' },
  { color: 'violet', desc: 'Violet', c_class: 'flag-violet', s_class: 'bg-violet-500 text-white  font-semibold tracking-wider' },
  { color: 'fuchsia', desc: 'Fuchsia', c_class: 'flag-fuchsia', s_class: 'bg-fuchsia-500 text-white  font-semibold tracking-wider' },
  { color: 'pink', desc: 'Pink', c_class: 'flag-pink', s_class: 'bg-pink-500 text-white  font-semibold tracking-wider' },
  { color: 'blue-gray', desc: 'Blue Gray', c_class: 'flag-blue-gray', s_class: 'bg-blue-gray-500 text-white  font-semibold tracking-wider' },
  { color: 'warm-gray', desc: 'Warm Gray', c_class: 'flag-warm-gray', s_class: 'bg-warm-gray-500 text-white  font-semibold tracking-wider' }
]
