import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class NotifyService {
  constructor(
    private toast: ToastrService
  ) {}

  showSuccess(title: string, msg: string) {
    this.toast.success(msg, title);
  }

  showWarning(title: string, msg: string) {
    this.toast.warning(msg, title);
  }

  showError(title: string, msg: string) {
    this.toast.error(msg, title);
  }

  showDefault(title: string, msg: string) {
    this.toast.info(msg, title);
  }

  show(code: number, msg: string) {
    switch (code) {
      case 403 || 404:
        this.showWarning('Error', msg);
        break;
      case 409:
        this.showWarning('Warning', msg);
        break;
      default:
        break;
    }
  }
}
