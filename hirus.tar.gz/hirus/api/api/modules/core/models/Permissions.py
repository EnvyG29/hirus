# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy import ForeignKey
from sqlalchemy.dialects import postgresql as psql

from .Projects import Projects

from ....lib.Db import TblBase

class Permissions(TblBase):
    __tablename__ = 'permissions'
    __table_args__ = {'schema': 'core'}

    cp_cp_id = Column(psql.INTEGER, ForeignKey(Projects.id), nullable=False)
    cp_name = Column(psql.VARCHAR(64), nullable=False)
    cp_desc = Column(psql.VARCHAR(255), nullable=False)
    cp_data = Column(psql.JSONB(), nullable=False, default='{}')
