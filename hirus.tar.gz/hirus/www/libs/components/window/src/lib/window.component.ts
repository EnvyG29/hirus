import { Component, Input, Output, ViewEncapsulation, ElementRef, OnInit, OnDestroy } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';

import { WindowService } from './services/window.service';

@Component({
  selector: 'mn-window',
  templateUrl: './window.component.html',
  styleUrls: ['./window.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('fade', [
      state('visible', style({
        opacity: 1
      })),
      state('hidden', style({
        opacity: 0
      })),
      transition('hidden => visible', [
        animate('250ms')
      ]),
      transition('visible => hidden', [
        animate('250ms')
      ])
    ])
  ]
})
export class WindowComponent implements OnInit, OnDestroy {
  @Input() id: string;
  @Input() wHeader: boolean = true;
  @Input() wFooter: boolean = true;
  @Input() wMinBtn: boolean = false;
  @Input() wMaxBtn: boolean = true;
  @Input() wCloseBtn: boolean = true;
  @Input() wFooterBtn: boolean = true;
  @Input() wWdth: string;

  isWindowVisible: boolean = false;

  private element: any;

  constructor(
    private wService: WindowService,
    private el: ElementRef
  ) {
    this.element = el.nativeElement;
  }

  ngOnInit() {
    if (!this.id) {
      console.error('window must have an id');
      return
    }

    document.body.appendChild(this.element);
    this.element.addEventListener('click', (el: any) => {
      if (el.target.classList === 'window-layer') {
        this.close();
      }
    });

    this.wService.add(this);
  }

  ngOnDestroy() {
    this.wService.remove(this.id);
    this.element.remove();
  }

  open() {
    this.isWindowVisible = true;
    this.element.firstChild.classList.add('window-open')
  }

  close() {
    this.isWindowVisible = false;
    setTimeout(() => {
      this.element.firstChild.classList.remove('window-open');
    }, 250);
  }
}
