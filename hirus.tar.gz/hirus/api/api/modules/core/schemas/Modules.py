# -*- coding: utf-8 -*-

from typing import List
from typing import Optional
from pydantic import Field
from pydantic import BaseModel

from ....common.schema.Response import SuccessResponse

class ModuleIcon(BaseModel):
    type: str = Field(..., description='Icon Type img|fa')
    val: List[str]

class ModuleCtl(BaseModel):
    group: str
    ctl: str
    desc: str

class ModuleMeta(BaseModel):
    name: str
    desc: str
    icon: ModuleIcon
    ctl: Optional[List[ModuleCtl]]
    mode: str
    type: str
    active: bool
    managed: bool

class Module(BaseModel):
    id: int
    cm_meta: ModuleMeta
    cp_id: int
    cpm_id: int
    cpm_cp_id: int
    cpm_cm_id: int
    enabled: bool

    class Config:
        orm_mode = True

class Modules(SuccessResponse):
    data: List[Module]

    class Config:
        arbitrary_types_allowed = True

"""
-------------------------------------------------------------------------------
{
    "name": "Test",
    "desc": "Test Module",
    "mode": "dev|test|prod",
    "type": "public|private",
    "icon": {
        "type": "fa",
        "val": ['fas', 'box-open']
    },
    "menu": {
        "label": "Test 1",
        "url": "/test",
        "icon": {
            "type": "fa",
            "val": ["fab", "google"]
        },
        child?: []
    },
    "ctl": [{
        "name": "",
        "desc": "",
        "mask": "1-15"
    }],
    "active": "true|false",
    "managed": "true|false"
}
"""
