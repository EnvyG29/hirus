------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Schema: core
-- Create: Date: 2019-11-25
-- Desc: Link Users and Role Table
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."projects_modules_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."projects_modules" (
     "id"                       INTEGER NOT NULL DEFAULT nextval('core.projects_modules_id_seq'::REGCLASS)
    ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"cpm_cp_id"                INTEGER NOT NULL REFERENCES "core"."projects" ("id") ON DELETE CASCADE
    ,"cpm_cm_id"                INTEGER NOT NULL REFERENCES "core"."modules" ("id") ON DELETE CASCADE
    ,PRIMARY KEY ("id")
    ,UNIQUE("cpm_cp_id", "cpm_cm_id")
);
ALTER SEQUENCE "core"."projects_modules_id_seq" OWNED BY "core"."projects_modules"."id";

CREATE INDEX "cpm_cp_id_idx" ON "core"."projects_modules" ("cpm_cp_id");
CREATE INDEX "cpm_cm_id_idx" ON "core"."projects_modules" ("cpm_cm_id");

-- Comment
COMMENT ON TABLE "core"."projects_modules" IS 'Link Users and Role Table';
COMMENT ON COLUMN "core"."projects_modules"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."projects_modules"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."projects_modules"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."projects_modules"."cpm_cp_id" IS 'Link to core.projects tables';
COMMENT ON COLUMN "core"."projects_modules"."cpm_cm_id" IS 'Link to core.modules tables';