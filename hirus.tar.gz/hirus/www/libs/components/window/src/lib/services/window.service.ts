import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WindowService {
  private windows: any[] = [];

  add(window: any) {
    this.windows.push(window);
  }

  remove(id: string) {
    this.windows = this.windows.filter(w => w.id !== id);
  }

  open(id: string) {
    const window = this.windows.find(w => w.id === id);
    window.open();
  }

  close(id: string) {
    const window = this.windows.find(w => w.id === id);
    window.close();
  }
}
