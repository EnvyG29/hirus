# -*- coding: utf-8 -*-

import logging

from fastapi import Body
from fastapi import Path
from fastapi import Depends
from fastapi.encoders import jsonable_encoder

from sqlalchemy.ext.asyncio import AsyncSession

from starlette.responses import JSONResponse

from ....common.depends.Auth import auth as dAuth
from ....common.depends.DbSession import get_db

from ....common.schema.Response import ErrorResponse as sErrorResponse

from ..schemas.Payloads import ProjectModulesChange as prModChange
from ..schemas.Modules import Modules as sModules

from ..services.Modules import get_modules
from ..services.Modules import update_modules

from .router import router

log = logging.getLogger('api.core.controller.modules')

@router.get(
    '/modules/{pid}/',
    response_model=sModules,
    responses={
        200: {'model': sModules},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse},
        403: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Modules']
)
async def modules_get(pid: int = Path(...), mn_sess: AsyncSession = Depends(get_db)):
    data = await get_modules(pid=pid, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sModules(data=data)))

@router.put(
    '/modules/',
    response_model=sModules,
    responses={
        200: {'model': sModules},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse},
        403: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Modules']
)
async def modules_put(req: prModChange = Body(...), mn_sess: AsyncSession = Depends(get_db)):
    await update_modules(req=req, sess=mn_sess)

    data = await get_modules(pid=req.pid, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sModules(data=data)))
