# components-dropdown

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test components-dropdown` to execute the unit tests.
