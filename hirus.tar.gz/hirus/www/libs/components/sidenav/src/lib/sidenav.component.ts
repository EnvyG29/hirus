import { Component, Input, OnInit } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';

import { SidenavItem } from './model/sidenav.model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'mn-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss'],
  animations: [
    trigger('inout', [
      transition(':enter', [
        style({ height: 0, overflow: 'hidden' }),
        animate('125ms', style({ height: '*' })),
      ]),
      transition(':leave', [
        style({ height: '*', overflow: 'hidden' }),
        animate('125ms', style({ height: 0 }))
      ])
    ])
  ]
})
export class SidenavComponent implements OnInit {
  @Input() menu: SidenavItem[] = [];
  route: any;

  constructor(
    router: Router
  ) {
    this.route = router.url
  }

  ngOnInit(): void {
  }

  itemOpenChange(i: number) {
    this.menu[i].isOpen = !this.menu[i].isOpen
  }
}
