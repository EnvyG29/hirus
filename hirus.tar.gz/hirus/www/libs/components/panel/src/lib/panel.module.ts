import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { PanelLegacyComponent as PanelLegacy } from "./legacy/panel-legacy.component";
import { PanelTreeComponent as PanelTree } from "./tree/panel-tree.component";

@NgModule({
  imports: [
    CommonModule,

    FontAwesomeModule
  ],
  exports: [
    PanelLegacy,
    PanelTree
  ],
  declarations: [
    PanelLegacy,
    PanelTree
  ]
})
export class PanelModule {}
