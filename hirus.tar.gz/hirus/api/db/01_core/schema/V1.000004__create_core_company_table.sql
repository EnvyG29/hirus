------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Schema: core
-- Create: Date: 2019-11-24
------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------
-- Desc: Create core.company Table
------------------------------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS "core"."company" CASCADE;

CREATE SEQUENCE "core"."company_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."company" (
     "id"                       INTEGER NOT NULL DEFAULT nextval('core.company_id_seq'::REGCLASS)
    ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"cc_name"                  CHARACTER VARYING (128) NOT NULL
    ,"cc_full"                  CHARACTER VARYING (255) NOT NULL
    ,"cc_info"                  JSONB NOT NULL
    ,"cc_enable"                BOOLEAN NOT NULL DEFAULT TRUE
    ,PRIMARY KEY ("id")
);
ALTER SEQUENCE "core"."company_id_seq" OWNED BY "core"."company"."id";

-- Comment
COMMENT ON TABLE "core"."company" IS 'Registred company';
COMMENT ON COLUMN "core"."company"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."company"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."company"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."company"."cc_name" IS 'Company Name';
COMMENT ON COLUMN "core"."company"."cc_full" IS 'Full Company Name';
COMMENT ON COLUMN "core"."company"."cc_info" IS 'Company Information';
COMMENT ON COLUMN "core"."company"."cc_enable" IS 'Enable|Disable company';
