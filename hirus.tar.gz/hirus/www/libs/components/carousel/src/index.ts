export * from './lib/model/carousel.model';

export * from './lib/carousel.module';
