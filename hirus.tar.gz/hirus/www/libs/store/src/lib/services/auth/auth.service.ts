import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment as env } from '@mn/environments';

import { AuthPayload } from '../../models';
import { AuthResponse } from '../../models';
import { ApiResponse } from '../../models';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(
    private http: HttpClient
  ) {}

  signIn( body: AuthPayload ) {
    return this.http.post<AuthResponse>(`${env.api}/core/login/`, body);
  }

  signRefresh() {
    return this.http.post<ApiResponse>(`${env.api}/core/refresh/`, {});
  }
}
