# -*- coding: utf-8 -*-

from sqlalchemy.dialects import postgresql as psql

from sqlalchemy import Column
from sqlalchemy import ForeignKey

from .Projects import Projects

from ....lib.Db import TblBase

class Roles(TblBase):
    __tablename__ = 'roles'
    __table_args__ = {'schema': 'core'}

    cr_cp_id = Column(psql.INTEGER, ForeignKey(Projects.id, ondelete="CASCADE"), nullable=False)
    lkey = Column('cr_lkey', psql.INTEGER, nullable=False)
    rkey = Column('cr_rkey', psql.INTEGER, nullable=False)
    lvl = Column('cr_lvl', psql.INTEGER, nullable=False)
    meta = Column('cr_meta', psql.JSONB(), nullable=False, server_default='{}')
    child = []
