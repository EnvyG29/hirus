# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy import ForeignKey
from sqlalchemy.dialects import postgresql as psql

from .Projects import Projects
from .Modules import Modules

from ....lib.Db import TblBase

class ProjectsModules(TblBase):
    __tablename__ = 'projects_modules'
    __table_args__ = {'schema': 'core'}

    cpm_cp_id = Column(psql.INTEGER, ForeignKey(Projects.id), nullable=False)
    cpm_cm_id = Column(psql.INTEGER, ForeignKey(Modules.id), nullable=False)
