import { Injectable, Inject, Injector, ErrorHandler } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

import { NotifyService } from '@mn/store';

@Injectable({
  providedIn: 'root'
})
export class ApiErrorHandler extends ErrorHandler {
  constructor(
    @Inject(Injector) private injector: Injector
  ) {
    super();
  }

  override handleError(error: HttpErrorResponse) {
    if ( error && error.error && error.error.data ) {
      this.notify.show(error.status, error.error.data);
    }
    super.handleError(error);
  }

  private get notify(): NotifyService {
    return this.injector.get(NotifyService);
  }
}
