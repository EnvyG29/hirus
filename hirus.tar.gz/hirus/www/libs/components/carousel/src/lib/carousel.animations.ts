import { animate, animation, group, query, style } from '@angular/animations';

export const incrementAnimation = animation([
  group([
    query(':enter', [
      style({ transform: 'translateX(0)', order: 1 }),
      animate('500ms', style({ transform: 'translateX(-100%)', order: 1 }))
    ]),
    query(':leave', [
      style({ transform: 'translateX(0)' }),
      animate('500ms', style({ transform: 'translateX(-100%)' }))
    ])
  ])
])

export const decrementAnimation = animation([
  group([
    query(':enter', [
      style({ transform: 'translateX(-100%)', order: -1 }),
      animate('500ms', style({ transform: 'translateX(0)', order: -1 }))
    ]),
    query(':leave', [
      style({ transform: 'translateX(-100%)' }),
      animate('500ms', style({ transform: 'translateX(0)' }))
    ])
  ])
])
