------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Create: Date: 2018-12-07
-- Desc: Permissions Data
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."permissions_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."permissions" (
   "id"                       INTEGER NOT NULL DEFAULT nextval('core.permissions_id_seq'::REGCLASS)
  ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  ,"cp_cp_id"                 INTEGER NOT NULL REFERENCES "core"."projects" ("id") ON DELETE CASCADE ON UPDATE CASCADE
  ,"cp_name"                  CHARACTER VARYING (64) NOT NULL
  ,"cp_desc"                  CHARACTER VARYING (255) NOT NULL
  ,"cp_data"                  JSONB NOT NULL DEFAULT '[]'
  ,PRIMARY KEY ("id")
  ,UNIQUE ("cp_cp_id", "cp_name")
);
ALTER SEQUENCE "core"."permissions_id_seq" OWNED BY "core"."permissions"."id";

-- Comment
COMMENT ON TABLE "core"."permissions" IS 'Registred company permissions';
COMMENT ON COLUMN "core"."permissions"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."permissions"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."permissions"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."permissions"."cp_cp_id" IS 'Link to core.projects table';
COMMENT ON COLUMN "core"."permissions"."cp_name" IS 'Permission name';
COMMENT ON COLUMN "core"."permissions"."cp_desc" IS 'Permission description';
COMMENT ON COLUMN "core"."permissions"."cp_data" IS 'Permission acl (JSONB)';
