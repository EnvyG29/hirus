import { Component, EventEmitter, HostBinding, TemplateRef, Input, Output } from '@angular/core';

import { NestedItems } from './model/nested.model';

@Component({
  selector: 'mn-hchart',
  templateUrl: './hchart.component.html',
  styleUrls: ['./hchart.component.scss']
})
export class HchartComponent {
  @Input() datasource: NestedItems;

  @Input() btnSettings: boolean = false;
  @Input() btnDelete: boolean = false;
  @Input() btnAdd: boolean = false;
  @Input() btnEdit: boolean = false;
  @Input() btnExtLink: boolean = false;
  @Input() btnDetails: boolean = false;

  @Input() bodyTemplate: TemplateRef<any>;
  @Input() headerTemplate: TemplateRef<any>;

  @Input() hasManager = false;
  @Input() direction: 'vertical' | 'horizontal' = 'vertical';

  @Output() onItemDblClick: EventEmitter<NestedItems> = new EventEmitter();

  @Output() onSettingsClick: EventEmitter<NestedItems> = new EventEmitter();
  @Output() onDelClick: EventEmitter<NestedItems> = new EventEmitter();

  @Output() onAddClick: EventEmitter<NestedItems> = new EventEmitter();
  @Output() onEditClick: EventEmitter<NestedItems> = new EventEmitter();
  @Output() onExtLinkClick: EventEmitter<NestedItems> = new EventEmitter();
  @Output() onDetailClick: EventEmitter<NestedItems> = new EventEmitter();

  @HostBinding('style.flex-direction')
  get hostClass() {
    return this.direction === 'vertical' ? 'column' : '';
  }
}
