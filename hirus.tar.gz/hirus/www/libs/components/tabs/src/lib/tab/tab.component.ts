import { Component, Input } from '@angular/core';

import { TabsComponent } from '../tabs.component';
import { Params } from '@angular/router';

@Component({
  selector: 'mn-tab',
  templateUrl: './tab.component.html',
  styleUrls: ['./tab.component.scss']
})
export class TabComponent {
  @Input() tabTitle: string;
  @Input() tabId: string;
  @Input() routerLink: string|null = null;
  @Input() queryParams: Params|null = null;

  active = false;

  constructor(
    tabs: TabsComponent
  ) {
    tabs.addTab(this);
  }
}
