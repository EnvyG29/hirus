------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Create: Date: 2019-11-25
-- Desc: Link Users and Role Table
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."users_roles_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."users_roles" (
   "id"                       INTEGER NOT NULL DEFAULT nextval('core.users_roles_id_seq'::REGCLASS)
  ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  ,"cur_cu_id"                INTEGER NOT NULL REFERENCES "core"."users" ("id") ON DELETE CASCADE
  ,"cur_cr_id"                INTEGER NOT NULL REFERENCES "core"."roles" ("id") ON DELETE CASCADE
  ,PRIMARY KEY ("id")
  ,UNIQUE("cur_cu_id", "cur_cr_id")
);
ALTER SEQUENCE "core"."users_roles_id_seq" OWNED BY "core"."users_roles"."id";

-- Comment
COMMENT ON TABLE "core"."users_roles" IS 'Link Users and Role Table';
COMMENT ON COLUMN "core"."users_roles"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."users_roles"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."users_roles"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."users_roles"."cur_cu_id" IS 'Link to core.users tables';
COMMENT ON COLUMN "core"."users_roles"."cur_cr_id" IS 'Link to core.roles tables';

------------------------------------------------------------------------------------------------------------------------
-- Views
------------------------------------------------------------------------------------------------------------------------
--
-- User Roles Relation
--
/*
DROP VIEW IF EXISTS "core"."user_roles_v";
CREATE VIEW "core"."user_roles_v" AS
  SELECT
     sr."id"                                            AS "id"
    ,sr."sr_sc_id"                                      AS "sr_sc_id"
    ,sr."sr_name"                                       AS "sr_name"
    ,sr."sr_desc"                                       AS "sr_desc"
    ,su."id"                                            AS "su_id"
    ,coalesce(sru."id", 0)                              AS "sru_id"
    ,coalesce(sru."sru_sr_id", 0)                       AS "sru_sr_id"
    ,coalesce(sru."sru_su_id", 0)                       AS "sru_su_id"
    ,coalesce((sru."sru_su_id" = su."id"), FALSE)       AS "enabled"
  FROM
    "core"."roles" AS "sr"
  CROSS JOIN
    "core"."users" AS "su"
  LEFT JOIN
    "core"."users_roles" AS "sru" ON sru."sru_sr_id" = sr."id" AND su."id" = sru."sru_su_id"
  ORDER bY
    sr."id";

--
-- Roles User Relation
--
DROP VIEW IF EXISTS "core"."users_roles_v";
CREATE VIEW "core"."users_roles_v" AS
  SELECT
     "su".id                                                AS "id"
    ,"scu"."scu_sc_id"                                      AS "sc_id"
    ,"sr"."id"                                              AS "sr_id"
    ,"su"."su_data"                                         AS "su_data"
    ,"scu"."is_admin"                                       AS "is_admin"
    ,coalesce("sru"."id", 0)                                AS "sru_id"
    ,coalesce("sru"."sru_sr_id", 0)                         AS "sru_sr_id"
    ,coalesce("sru"."sru_su_id", 0)                         AS "sru_su_id"
    ,coalesce(("sru"."sru_su_id" = su."id"), FALSE)         AS "enabled"
  FROM
    "core"."company_users" AS scu
  JOIN
    "core"."users" as su ON scu.scu_su_id = su.id
  CROSS JOIN
    "core"."roles" AS "sr"
  LEFT JOIN
    "core"."users_roles" AS "sru" ON sru."sru_sr_id" = sr."id" AND su."id" = sru."sru_su_id"
  ORDER bY
    su."id";

explain analyze SELECT * FROM "core"."users_roles_v" where sc_id = 1 and sr_id = 2;
*/
