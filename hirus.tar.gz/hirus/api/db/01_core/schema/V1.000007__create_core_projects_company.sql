------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Schema: core
-- Create: Date: 2019-11-25
-- Desc: Link Users and Role Table
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."projects_company_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."projects_company" (
     "id"                       INTEGER NOT NULL DEFAULT nextval('core.projects_company_id_seq'::REGCLASS)
    ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"cpc_cp_id"                INTEGER NOT NULL REFERENCES "core"."projects" ("id") ON DELETE CASCADE
    ,"cpc_cc_id"                INTEGER NOT NULL REFERENCES "core"."company" ("id") ON DELETE CASCADE
    ,PRIMARY KEY ("id")
    ,UNIQUE("cpc_cp_id", "cpc_cc_id")
);
ALTER SEQUENCE "core"."projects_company_id_seq" OWNED BY "core"."projects_company"."id";

-- Comment
COMMENT ON TABLE "core"."projects_company" IS 'Link Users and Role Table';
COMMENT ON COLUMN "core"."projects_company"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."projects_company"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."projects_company"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."projects_company"."cpc_cp_id" IS 'Link to core.projects tables';
COMMENT ON COLUMN "core"."projects_company"."cpc_cc_id" IS 'Link to core.company tables';