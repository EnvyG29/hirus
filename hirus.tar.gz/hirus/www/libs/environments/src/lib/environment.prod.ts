export const environment = {
  production: true,
  api: '/api/v2',
  ddKey: '3b0dfbb5d8c294122ddfabbc28ff39c09cb798cb'
};
