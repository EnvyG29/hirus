# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy import func
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.ext.asyncio import create_async_engine

from sqlalchemy.dialects import postgresql as psql

from cfg.api import config as cfg

Base = declarative_base()

eng_api = create_async_engine(cfg.SA_URL, echo=True)

sess_api = sessionmaker(
    eng_api, class_=AsyncSession, expire_on_commit=False
)

class TblBase(Base):
    __abstract__: bool = True

    id = Column(psql.INTEGER, primary_key=True)
    create_at = Column(psql.TIMESTAMP, nullable=False, default=func.now())
    update_at = Column(psql.TIMESTAMP, nullable=False, default=func.now())

    @staticmethod
    def build_icon(i_body):
        i_dict = None

        if i_body.type == 'fa':
            i_dict = {
                'type': 'fa',
                'val': [i_body.font, i_body.iname]
            }
        elif i_body.type == 'img':
            i_dict = {
                'type': 'img',
                'val': i_body.path
            }

        return i_dict
