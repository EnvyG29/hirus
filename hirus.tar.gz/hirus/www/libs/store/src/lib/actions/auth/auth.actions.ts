import { createAction, props } from '@ngrx/store';

import {
  AuthPayload,
  AuthResponse,
  UserProfile
} from '../../models';

export const SignIn = createAction(
  '[App/Auth] Login the existing user',
  props<{ payload: AuthPayload }>()
)

export const SignInSuccess = createAction(
  '[Api/Auth] Login the existing user success',
  props<{ payload: AuthResponse }>()
)

export const SignInResore = createAction(
  '[App/Auth] Restore existing user session',
  props<{ payload: UserProfile }>()
)

export const AuthTokenRefresh = createAction(
  '[App/Auth] Refresh token'
)

export const  AuthTokenRefreshSuccess = createAction(
  '[App/Auth] Refresh token success'
)

export const authActions = {
  SignIn,
  SignInSuccess,
  SignInResore,
  AuthTokenRefresh,
  AuthTokenRefreshSuccess
}
