# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy import ForeignKey
from sqlalchemy.dialects import postgresql as psql

from .Projects import Projects
from .Company import Company

from ....lib.Db import TblBase

class ProjectsCompany(TblBase):
    __tablename__ = 'projects_company'
    __table_args__ = {'schema': 'core'}

    cpc_cp_id = Column(psql.INTEGER, ForeignKey(Projects.id), nullable=False)
    cpc_cc_id = Column(psql.INTEGER, ForeignKey(Company.id), nullable=False)
