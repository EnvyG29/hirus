export interface ApiResponse {
  success: boolean;
}
