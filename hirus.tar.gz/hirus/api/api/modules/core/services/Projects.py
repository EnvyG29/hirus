# -*- coding: utf-8 -*-

import logging

from sqlalchemy import select
from sqlalchemy import update
from sqlalchemy import delete

from sqlalchemy import and_
from sqlalchemy import case
from sqlalchemy.ext.asyncio import AsyncSession

from ..models.Projects import Projects as mProjects
from ..schemas.Payloads import AddEditProject as pAddEditProject

log = logging.getLogger('api.core.service.projects')

async def _get_proj(nid: int = None, sess: AsyncSession = None):
    if nid is None:
        t_data = await sess.execute(
            select(mProjects)
            .filter(
                mProjects.lvl == 1
            )
            .order_by(mProjects.lkey)
        )

        data = t_data.scalars().all()

    if nid is not None:
        r_tmp = await sess.execute(
            select(mProjects)
            .filter(
                mProjects.id == nid
            )
            .order_by(mProjects.lkey)
        )

        r_data = r_tmp.scalars().first()

        if (r_data.rkey - r_data.lkey) > 1:
            t_data = await sess.execute(
                select(mProjects)
                .filter(
                    and_(
                        mProjects.lkey > r_data.lkey,
                        mProjects.rkey < r_data.rkey,
                        mProjects.lvl == r_data.lvl + 1
                    )
                ).order_by(mProjects.lkey)
            )

            return t_data.scalars().all()

    return data

async def _build_proj(nid: int = None, sess: AsyncSession = None):
    proj = []

    data = await _get_proj(nid=nid, sess=sess)

    for item in data:
        if (item.rkey - item.lkey) > 1:
            chld = await _build_proj(nid=item.id, sess=sess)
            item.child = chld

        proj.append(item)

    return proj

async def get_projects(sess: AsyncSession):
    tree = await _build_proj(sess=sess)

    return tree

async def add_project(req: pAddEditProject, sess: AsyncSession):
    t_icon = mProjects.build_icon(i_body=req.icon)
    t_par = await sess.execute(
        select(mProjects)
        .filter(
            mProjects.id == req.pid
        )
    )

    par = t_par.scalars().first()
    t_rkey = par.rkey

    await sess.execute(
        update(mProjects)
        .where(
            mProjects.rkey >= t_rkey
        ).values(
            lkey=case([
                (mProjects.lkey > t_rkey, mProjects.lkey + 2)
            ], else_=mProjects.lkey),
            rkey=case([
                (mProjects.rkey >= t_rkey, mProjects.rkey + 2)
            ], else_=mProjects.rkey)
        )
    )
    await sess.commit()

    i_pr = mProjects(
        lkey=t_rkey,
        rkey=t_rkey + 1,
        lvl=par.lvl + 1,
        meta={
            'name': req.name,
            'desc': req.desc,
            'icon': t_icon
        }
    )
    sess.add(i_pr)
    await sess.commit()

    tree = await _build_proj(sess=sess)
    return tree

async def update_project(req: pAddEditProject, sess: AsyncSession):
    t_icon = mProjects.build_icon(i_body=req.icon)

    await sess.execute(
        update(mProjects)
        .where(
            mProjects.id == req.id
        )
        .values(
            meta={
                'name': req.name,
                'desc': req.desc,
                'icon': t_icon
            }
        )
    )
    await sess.commit()

    tree = await _build_proj(sess=sess)
    return tree

async def delete_project(pid: int, sess: AsyncSession):
    d_tmp = await sess.execute(
        select(mProjects)
        .filter(
            mProjects.id == pid
        )
    )

    p_tmp = d_tmp.scalars().first()
    delta = p_tmp.rkey - p_tmp.lkey + 1

    await sess.execute(
        delete(mProjects)
        .filter(
            and_(
                mProjects.lkey >= p_tmp.lkey,
                mProjects.rkey <= p_tmp.rkey
            )
        )
    )
    await sess.commit()

    await sess.execute(
        update(mProjects)
        .where(
            mProjects.rkey >= p_tmp.rkey
        )
        .values(
            lkey=case([
                (mProjects.lkey > p_tmp.lkey, mProjects.lkey - delta)
            ], else_=mProjects.lkey),
            rkey=case([
                (mProjects.rkey >= p_tmp.rkey, mProjects.rkey - delta)
            ], else_=mProjects.rkey)
        )
    )
    await sess.commit()

    tree = await _build_proj(sess=sess)
    return tree
