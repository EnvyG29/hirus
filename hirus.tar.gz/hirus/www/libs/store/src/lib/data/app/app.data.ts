import { SidenavItem } from '@mn/components/sidenav';

export const SideNav: SidenavItem[] = [{
  label: 'Dashboard',
  link: '/dash',
  icon: {
    type: 'fa',
    val: ['fas', 'tachometer-alt']
  },
  isOpen: false,
  disabled: false,
  child: []
}];
