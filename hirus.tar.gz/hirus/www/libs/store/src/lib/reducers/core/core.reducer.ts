import { createReducer, on } from '@ngrx/store';

import { CoreState } from '../../models';
import {
  modulesActions,
  coreActions,
  projectActions,
  rolesActions,
  permissionsActions,
  wbActions
} from '../../actions';

export const coreNode = 'core';

export const initialCoreState: CoreState = {
  currProj: null,
  currPerm: null,
  modules: null,
  roles: null,
  projects: null,
  permissions: null,
  wb: null
}

export const coreReducer = createReducer(
  initialCoreState,

  // Core
  on(coreActions.SetCurrProj, (state, { pid }) => {
    return {
      ...state,
      currProj: pid
    }
  }),

  // Workboard Config
  on(wbActions.GetWbConfig, (state) => {
    return {
      ...state
    }
  }),

  on(wbActions.GetWbConfigSuccess, (state, { payload }) => {
    return {
      ...state,
      wb: payload.data
    }
  }),

  on(wbActions.AddWbCols, (state, { payload }) => {
    let currWb = { ...state.wb };
    let cols = [...currWb.kw_cols];

    cols.push(payload);
    cols.sort((col1, col2) => {
      return col1.order - col2.order
    });

    currWb.kw_cols = [...cols];

    return {
      ...state,
      wb: currWb
    }
  }),

  on(wbActions.EditWbCols, (state, { payload }) => {
    let currWb = { ...state.wb };
    let cols = [...currWb.kw_cols];

    const idx = cols.findIndex(wc => wc.tag === payload.tag);

    cols[idx] = payload;

    cols.sort((col1, col2) => {
      return col1.order - col2.order
    });

    currWb.kw_cols = [...cols];

    return {
      ...state,
      wb: currWb
    }
  }),

  on(wbActions.DelWbCols, (state, { payload }) => {
    let currWb = { ...state.wb };
    let cols = [...currWb.kw_cols];

    const idx = cols.findIndex(wc => wc.tag === payload.tag);

    cols.splice(idx, 1);

    cols.sort((col1, col2) => {
      return col1.order - col2.order
    });

    currWb.kw_cols = [...cols];

    return {
      ...state,
      wb: currWb
    }
  }),

  on(wbActions.AddWbBadge, (state, { payload }) => {
    let currWb = { ...state.wb };
    let badges = [...currWb.kw_badge];

    badges.push(payload);

    currWb.kw_badge = [...badges];

    return {
      ...state,
      wb: currWb
    }
  }),

  on(wbActions.EditWbBadge, (state, { payload }) => {
    let currWb = { ...state.wb };
    let badges = [...currWb.kw_badge];

    const idx = badges.findIndex(wb => wb.tag === payload.tag);

    badges[idx] = payload;

    currWb.kw_badge = [...badges];

    return {
      ...state,
      wb: currWb
    }
  }),

  on(wbActions.DelWbBadge, (state, { payload }) => {
    let currWb = { ...state.wb };
    let badges = [...currWb.kw_badge];

    const idx = badges.findIndex(wb => wb.tag === payload.tag);

    badges.splice(idx, 1);

    currWb.kw_badge = [...badges];

    return {
      ...state,
      wb: currWb
    }
  }),

  on(wbActions.AddWbPrio, (state, { payload }) => {
    let currWb = { ...state.wb };
    let prio = [...currWb.kw_prio];

    prio.push(payload);

    currWb.kw_prio = [...prio];

    return {
      ...state,
      wb: currWb
    }
  }),

  on(wbActions.EditWbPrio, (state, { payload }) => {
    let currWb = { ...state.wb };
    let prio = [...currWb.kw_prio];

    const idx = prio.findIndex(wp => wp.tag === payload.tag);

    prio[idx] = payload;

    currWb.kw_prio = [...prio];

    return {
      ...state,
      wb: currWb
    }
  }),

  on(wbActions.DelWbPrio, (state, { payload }) => {
    let currWb = { ...state.wb };
    let prio = [...currWb.kw_prio];

    const idx = prio.findIndex(wp => wp.tag === payload.tag);

    prio.splice(idx, 1);

    currWb.kw_prio = [...prio];

    return {
      ...state,
      wb: currWb
    }
  }),

  on(wbActions.ApplyWbColConfig, (state) => {
    return {
      ...state
    }
  }),

  on(wbActions.ApplyWbBadgeConfig, (state) => {
    return {
      ...state
    }
  }),

  on(wbActions.ApplyWbPrioConfig, (state) => {
    return {
      ...state
    }
  }),

  // Projects
  on(projectActions.GetProjects, (state) => {
    return {
      ...state
    }
  }),

  on(projectActions.AddProject, (state) => {
    return {
      ...state
    }
  }),

  on(projectActions.EditProject, (state) => {
    return {
      ...state
    }
  }),

  on(projectActions.DeleteProject, (state) => {
    return {
      ...state
    }
  }),

  on(projectActions.GetProjectsSuccess, (state, { payload }) => {
    return {
      ...state,
      projects: payload.data
    }
  }),

  // Roles
  on(rolesActions.GetRoles, (state) => {
    return {
      ...state
    }
  }),

  on(rolesActions.AddRole, (state) => {
    return {
      ...state
    }
  }),

  on(rolesActions.EditRole, (state) => {
    return {
      ...state
    }
  }),

  on(rolesActions.DeleteRole, (state) => {
    return {
      ...state
    }
  }),

  on(rolesActions.GetRolesSuccess, (state, { payload }) => {
    return {
      ...state,
      roles: payload.data
    }
  }),

  // Modules
  on(modulesActions.GetModules, (state) => {
    return {
      ...state
    }
  }),

  on(modulesActions.ProjectModulesChange, (state) => {
    return {
      ...state
    }
  }),

  on(modulesActions.GetModulesSuccess, (state, { payload }) => {
    return {
      ...state,
      modules: payload.data
    }
  }),

  // Workboard Config
  on(permissionsActions.GetPermissions, (state) => {
    return {
      ...state
    }
  }),

  on(permissionsActions.GetPermissionsSuccess, (state, { payload }) => {
    return {
      ...state,
      permissions: payload.data
    }
  }),

  on(permissionsActions.ChangeCurrPerm, (state, { perm }) => {
    return {
      ...state,
      currPerm: perm
    }
  }),

  on(permissionsActions.PermGantAdd, (state, { payload }) => {
    let tmpPerm = [...state.permissions];
    let tmpIdx = tmpPerm.findIndex(p => p.id === state.currPerm);

    let cPerm = { ...tmpPerm.filter(p => p.id === state.currPerm)[0] };
    let cp_data = [ ...cPerm.cp_data ]
    cp_data.push(payload)

    cPerm.cp_data = [ ...cp_data ]
    tmpPerm[tmpIdx] = { ...cPerm };

    console.log(cPerm)

    return {
      ...state,
      permissions: [ ...tmpPerm ]
    }
  }),
)
