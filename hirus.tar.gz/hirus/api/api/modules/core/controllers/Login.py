# -*- coding: utf-8 -*-

import jwt
import logging

from datetime import datetime
from datetime import timedelta

from fastapi import Body
from fastapi import Path
from fastapi import Depends
from fastapi.encoders import jsonable_encoder

from starlette.responses import JSONResponse

from sqlalchemy.ext.asyncio import AsyncSession

from ....common.depends.Auth import assign_session

from ....common.depends.Auth import auth as dAuth
from ....common.depends.DbSession import get_db
from ....common.schema.TokenData import TokenData

from ....common.schema.Response import Errors
from ....common.schema.Response import ErrorResponse as sErrorResponse
from ....common.schema.Response import error_response

from ..schemas.Users import User as sUser
from ..schemas.Payloads import Login as pLogin
from ..schemas.WsToken import WsToken as sWsToken

from ..services.Login import check_user

from .router import router

from cfg.api import config as cfg

log = logging.getLogger('api.core.controller.login')

@router.get(
    '/login/',
    response_model=sWsToken,
    responses={
        200: {'model': sWsToken},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse}
    },
    description='Get Websocket Token',
    tags=['Core/Auth']
)
async def token_get(auth: TokenData = Depends(dAuth)):
    now = datetime.utcnow()
    token = TokenData(ws=True, user_id=str(auth.user_id)).dict()
    token.update(iat=now, exp=now + timedelta(seconds=cfg.WS_TOKEN_AGE))

    token_signed = jwt.encode(token, cfg.JWT_SECRET_KEY, algorithm=cfg.JWT_ALGO)

    data = sWsToken(data={'token': token_signed})
    return JSONResponse(content=jsonable_encoder(data))

@router.post(
    '/login/',
    response_model=sUser,
    responses={
        200: {'model': sUser},
        400: {'model': sErrorResponse},
        403: {'model': sErrorResponse},
        409: {'model': sErrorResponse},
    },
    tags=['Core/Auth']
)
async def login_post(req: pLogin = Body(...), mn_sess: AsyncSession = Depends(get_db)):
    user = await check_user(req.username, req.password, sess=mn_sess)

    return assign_session(JSONResponse(content=jsonable_encoder(sUser(data=user))), user)
