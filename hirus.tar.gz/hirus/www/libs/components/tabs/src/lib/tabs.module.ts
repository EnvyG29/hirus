import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { TabComponent as Tab } from './tab/tab.component';
import { TabsComponent as Tabs } from './tabs.component';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    CommonModule,
    FontAwesomeModule,
    RouterModule
  ],
  exports: [
    Tab,
    Tabs
  ],
  declarations: [
    Tab,
    Tabs
  ]
})
export class TabsModule {}
