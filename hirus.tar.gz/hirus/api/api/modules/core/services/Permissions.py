import logging

from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models.Permissions import Permissions as mPermissions

log = logging.getLogger('api.core.service.permissions')

async def get_permissions(pid: int, sess: AsyncSession):
    t_data = await sess.execute(
        select(mPermissions)
        .filter(mPermissions.cp_cp_id == pid)
        .order_by(mPermissions.id)
    )

    return t_data.scalars().all()
