from typing import List
from typing import Optional
from pydantic import BaseModel

from ....common.schema.TblBase import TblBase
from ....common.schema.Response import SuccessResponse

class RoleIcon(BaseModel):
    type: str
    val: List[str]

class RoleMeta(BaseModel):
    name: str
    desc: str
    icon: RoleIcon

class RoleData(TblBase):
    lkey: int
    rkey: int
    lvl: int
    meta: Optional[RoleMeta]
    child: Optional[List['RoleData']] = None

    class Config:
        orm_mode = True

RoleData.update_forward_refs()

class Roles(SuccessResponse):
    data: RoleData

    class Config:
        arbitrary_types_allowed = True
