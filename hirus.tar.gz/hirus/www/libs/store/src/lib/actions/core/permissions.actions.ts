import { createAction, props } from '@ngrx/store';

import {
  ModuleCtl,
  PermItem,
  PermResponse
} from '../../models';

export const GetPermissions = createAction(
  '[App/Core] Get Project Permissions'
)

export const GetPermissionsSuccess = createAction(
  '[Api/Core] Get Project Permissions Success',
  props<{ payload: PermResponse }>()
)

export const ChangeCurrPerm = createAction(
  '[Api/Core] PermChangeApply',
  props<{ perm: number }>()
)

export const PermGantAdd = createAction(
  '[Api/Core] Perm Grant Add',
  props<{ payload: ModuleCtl }>()
)

export const PermGantRemove = createAction(
  '[Api/Core] Perm Grant Remove',
  props<{ pname: string }>()
)

export const PermChangeApply = createAction(
  '[Api/Core] Perm Change Apply',
  props<{ payload: ModuleCtl[] }>()
)

export const permissionsActions = {
  GetPermissions,
  GetPermissionsSuccess,
  ChangeCurrPerm,
  PermGantAdd,
  PermGantRemove,
  PermChangeApply
}
