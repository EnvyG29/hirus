import { createSelector, createFeatureSelector } from '@ngrx/store';

import {
  CoreState,
  WbCols,
  WbBadges,
  WbPrio,
  WbConfig
} from '../../models';

import { coreNode } from '../../reducers';

export const wbFeatures = createFeatureSelector<CoreState>(coreNode);

export const getWbConfig = createSelector(
  wbFeatures,
  (state: CoreState): WbConfig => state.wb
)

export const getWbId = createSelector(
  wbFeatures,
  (state: CoreState): number => state.wb?.id
)

export const getWbCols = createSelector(
  wbFeatures,
  (state: CoreState): WbCols[] => state.wb?.kw_cols
)

export const getWbBadges = createSelector(
  wbFeatures,
  (state: CoreState): WbBadges[] => state.wb?.kw_badge
)

export const getWbPrio = createSelector(
  wbFeatures,
  (state: CoreState): WbPrio[] => state.wb?.kw_prio
)
