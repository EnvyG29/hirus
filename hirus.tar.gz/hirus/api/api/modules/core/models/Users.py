# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy.dialects import postgresql as psql
from werkzeug.security import check_password_hash

from ....lib.Db import TblBase

class Users(TblBase):
    __tablename__ = 'users'
    __table_args__ = {'schema': 'core'}

    cu_passwd = Column(psql.VARCHAR(255), nullable=False)
    cu_profile = Column(psql.JSONB(), nullable=False, default='{}')
    cu_padm = Column(psql.BOOLEAN, nullable=False, default=False)
    cu_enable = Column(psql.BOOLEAN, nullable=False, default=True)

    def check_password(self, passwd=None):
        return check_password_hash(self.cu_passwd, passwd)
