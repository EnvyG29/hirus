export interface Files {
  id?: number;
  name: string;
  desc?: string;
  meta: {
    orig_name: string;
    mime: string;
    path: string;
  };
}

export interface Uploads {
  data: any;
  type: string;
  inProgress: boolean;
  progress: number;
}
