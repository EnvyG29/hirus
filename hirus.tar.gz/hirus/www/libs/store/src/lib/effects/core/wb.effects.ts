import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';

import { map, withLatestFrom, mergeMap, switchMap } from 'rxjs/operators';

import { CoreState } from '@mn/store';
import { ApplyWbColConfig, wbActions } from '@mn/store';

import {
  getCurrProj,
  getWbId,
  getWbCols,
  getWbBadges,
  getWbPrio
} from '@mn/store';

import {
  WbService
} from '@mn/store';

@Injectable({
  providedIn: 'root'
})
export class WbEffects {
  constructor(
    private actions$: Actions,
    private wbService: WbService,
    private store: Store<CoreState>
  ) {
  }

  getWbConfig$ = createEffect(() => this.actions$.pipe(
    ofType(wbActions.GetWbConfig),
    withLatestFrom(this.store.select(getCurrProj)),
    mergeMap(([action, pid]) => this.wbService.getWbConfig(pid)
      .pipe(
        map(res => {
          return wbActions.GetWbConfigSuccess({payload: res});
        })
      )
    )
  ));

  applyWbCols$ = createEffect(() => this.actions$.pipe(
    ofType(wbActions.ApplyWbColConfig),
    withLatestFrom(this.store.select(getWbId), this.store.select(getWbCols)),
    mergeMap(([action, wid, cols]) => this.wbService.applyWbColConfig(wid, cols)
      .pipe(
        map(res => {
          return wbActions.GetWbConfigSuccess({payload: res});
        })
      )
    )
  ));

  applyWbBadges$ = createEffect(() => this.actions$.pipe(
    ofType(wbActions.ApplyWbBadgeConfig),
    withLatestFrom(this.store.select(getWbId), this.store.select(getWbBadges)),
    mergeMap(([action, wid, badges]) => this.wbService.applyWbBadgeConfig(wid, badges)
      .pipe(
        map(res => {
          return wbActions.GetWbConfigSuccess({payload: res});
        })
      )
    )
  ));

  applyWbPrio$ = createEffect(() => this.actions$.pipe(
    ofType(wbActions.ApplyWbPrioConfig),
    withLatestFrom(this.store.select(getWbId), this.store.select(getWbPrio)),
    mergeMap(([action, wid, prio]) => this.wbService.applyWbPrioConfig(wid, prio)
      .pipe(
        map(res => {
          return wbActions.GetWbConfigSuccess({payload: res});
        })
      )
    )
  ));
}
