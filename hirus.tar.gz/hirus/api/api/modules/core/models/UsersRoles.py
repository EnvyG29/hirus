# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy import ForeignKey
from sqlalchemy.dialects import postgresql as psql

from .Users import Users
from .Roles import Roles

from ....lib.Db import TblBase

class UsersRoles(TblBase):
    __tablename__ = 'users_roles'
    __table_args__ = {'schema': 'core'}

    cur_cu_id = Column(psql.INTEGER, ForeignKey(Users.id), nullable=False)
    cur_cr_id = Column(psql.INTEGER, ForeignKey(Roles.id), nullable=False)
