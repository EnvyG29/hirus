# -*- coding: utf-8 -*-

from pydantic import BaseModel

from ....common.schema.Response import SuccessResponse

class TokenItem(BaseModel):
    token: str

class WsToken(SuccessResponse):
    data: TokenItem
