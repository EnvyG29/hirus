export * from './lib/tabs.module';
