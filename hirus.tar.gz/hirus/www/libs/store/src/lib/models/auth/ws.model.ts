import { ApiResponse } from '../app/api-response.model';

export interface WsToken extends ApiResponse {
  data: {
    token: string
  };
}
