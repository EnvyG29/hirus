import logging

from fastapi import Body
from urllib.parse import parse_qs

from starlette.datastructures import Headers

log = logging.getLogger('api.common.depends.xform')

async def xsbform(body: str = Body(None)) -> dict:
    log.warning('Body => {}'.format(parse_qs(body)))
    t_data = parse_qs(body)
    data = {}

    for key in t_data:
        data[key.lower()] = t_data[key][0]
        # log.warning('Key => {}, Val => {}'.format(key.lower(), t_data[key][0]))

    return data
