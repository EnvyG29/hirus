import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { map, switchMap } from 'rxjs/operators';

import { projectActions } from '@mn/store';

import {
  ProjectsService
} from '@mn/store';

@Injectable({
  providedIn: 'root'
})
export class ProjectsEffects {
  constructor(
    private actions$: Actions,
    private pService: ProjectsService,
  ) {
  }

  getProjects$ = createEffect(() => this.actions$.pipe(
    ofType(projectActions.GetProjects),
    switchMap(() => this.pService.getProjects()
      .pipe(
        map(res => {
          return projectActions.GetProjectsSuccess({payload: res});
        })
      )
    )
  ));

  addProject$ = createEffect(() => this.actions$.pipe(
    ofType(projectActions.AddProject),
    switchMap(action => this.pService.addProject(action.payload)
      .pipe(
        map(res => {
          return projectActions.GetProjectsSuccess({payload: res});
        })
      )
    )
  ));

  editRole$ = createEffect(() => this.actions$.pipe(
    ofType(projectActions.EditProject),
    switchMap(action => this.pService.editProject(action.payload)
      .pipe(
        map(res => {
          return projectActions.GetProjectsSuccess({payload: res});
        })
      )
    )
  ));

  deleteRoles$ = createEffect(() => this.actions$.pipe(
    ofType(projectActions.DeleteProject),
    switchMap(action => this.pService.deleteProject(action.rid)
      .pipe(
        map(res => {
          return projectActions.GetProjectsSuccess({payload: res});
        })
      )
    )
  ));
}
