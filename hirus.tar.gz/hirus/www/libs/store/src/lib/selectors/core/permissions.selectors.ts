import { createSelector, createFeatureSelector } from '@ngrx/store';

import {
  CoreState,
  PermItem
} from '../../models';

import { coreNode } from '../../reducers';

export const permissionsFeatures = createFeatureSelector<CoreState>(coreNode);

export const getCurrPerm = createSelector(
  permissionsFeatures,
  (state: CoreState): number => state.currPerm
)

export const getCurrPermData = createSelector(
  permissionsFeatures,
  (state: CoreState): PermItem => {
    if (state.currPerm) {
      return { ...state.permissions.filter(p => p.id === state.currPerm)[0] }
    } else {
      return null;
    }
  }
)

export const getPermissions = createSelector(
  permissionsFeatures,
  (state: CoreState): PermItem[] => state.permissions
)
