# -*- coding: utf-8 -*-

import logging

from sqlalchemy import Column
from sqlalchemy import and_
from sqlalchemy import case
from sqlalchemy.dialects import postgresql as psql

from ....lib.Db import TblBase

class Projects(TblBase):
    __tablename__ = 'projects'
    __table_args__ = {'schema': 'core'}

    lkey = Column('cp_lkey', psql.INTEGER, nullable=False)
    rkey = Column('cp_rkey', psql.INTEGER, nullable=False)
    lvl = Column('cp_lvl', psql.INTEGER, nullable=False)
    meta = Column('cp_meta', psql.JSONB(), nullable=False, server_default='{}')
    cp_enable = Column(psql.BOOLEAN(), nullable=False, default=True)
    child = []

    """
    @classmethod
    def get_tree(cls, nid=None):
        r_tmp = None

        if nid is None:
            r_tmp = cls.query.filter(
                cls.lvl == 1
            ).order_by(cls.lkey).all()

        if nid is not None:
            r_tmp = cls.query.filter(
                cls.id == nid
            ).order_by(cls.lkey).first()

            if (r_tmp.rkey - r_tmp.lkey) > 1:
                t_data = cls.query.filter(
                    and_(
                        cls.lkey > r_tmp.lkey,
                        cls.rkey < r_tmp.rkey,
                        cls.lvl == r_tmp.lvl + 1
                    )
                ).order_by(cls.lkey).all()

                return t_data

        return r_tmp

    @classmethod
    def add_project(cls, body):
        i_dict = cls.build_icon(i_body=body['icon'])

        p_tmp = cls.query.where(
            cls.id == body['pid']
        ).order_by(cls.lkey).first()
        t_rkey = p_tmp.rkey

        t_upd = cls.__table__.update(
            and_(
                cls.rkey >= t_rkey
            )
        ).values(
            cp_lkey=case([
                (cls.lkey > t_rkey, cls.lkey + 2)
            ], else_=cls.lkey),
            cp_rkey=case([
                (cls.rkey >= t_rkey, cls.rkey + 2)
            ], else_=cls.rkey)
        )

        db.session.execute(t_upd)
        db.session.commit()

        obj = cls(
            lkey=t_rkey,
            rkey=t_rkey + 1,
            lvl=p_tmp.lvl + 1,
            meta={
                'name': body['name'],
                'desc': body['desc'],
                'icon': i_dict
            }
        )

        db.session.add(obj)
        db.session.commit()

        return True

    @classmethod
    def del_project(cls, rid=None):
        d_tmp = cls.query.filter(
            cls.id == rid
        ).order_by(cls.lkey).first()

        delta = d_tmp.rkey - d_tmp.lkey + 1

        cls.query.filter(
            and_(
                cls.lkey >= d_tmp.lkey,
                cls.rkey <= d_tmp.rkey,
            )
        ).delete()

        t_upd = cls.__table__.update(
            and_(
                cls.rkey > d_tmp.rkey
            )
        ).values(
            cp_lkey=case([
                (cls.lkey > d_tmp.lkey, cls.lkey - delta)
            ], else_=cls.lkey),
            cp_rkey=case([
                (cls.rkey >= d_tmp.rkey, cls.rkey - delta)
            ], else_=cls.rkey)
        )

        db.session.execute(t_upd)
        db.session.commit()

        return True

    @classmethod
    def update_project(cls, body=None):
        i_dict = cls.build_icon(i_body=body['icon'])

        t_upd = cls.__table__.update(
            cls.id == body['id']
        ).values(
            cp_meta={
                'name': body['name'],
                'desc': body['desc'],
                'icon': i_dict
            }
        )

        db.session.execute(t_upd)
        db.session.commit()

        return True
    """
