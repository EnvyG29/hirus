import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { AuthRouting } from './auth.routing';

import { AuthComponent } from './auth.component';
import { LoginComponent } from './login/login.component';
import { ForgotComponent } from './forgot/forgot.component';
import { ActivateComponent } from './activate/activate.component';
import { RegisterComponent } from './register/register.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,

    FontAwesomeModule,

    AuthRouting
  ],
  declarations: [
    AuthComponent,
    LoginComponent,
    ForgotComponent,
    ActivateComponent,
    RegisterComponent
  ]
})
export class AuthModule { }
