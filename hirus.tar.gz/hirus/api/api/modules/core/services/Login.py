# -*- coding: utf-8 -*-

import logging

from sqlalchemy.future import select
from sqlalchemy import or_
from sqlalchemy.ext.asyncio import AsyncSession

from werkzeug.security import check_password_hash

from ....common.exceptions.RaiseEx import RaiseEx

from ..models.Users import Users as mUsers

log = logging.getLogger('api.core.service.login')

async def check_user(username: str, passwd: str, sess: AsyncSession):
    t_data = await sess.execute(
        select(mUsers)
        .filter(
            or_(
                mUsers.cu_profile['credentials']['tel'].astext == username,
                mUsers.cu_profile['credentials']['email'].astext == username
            )
        )
    )

    user = t_data.scalars().first()

    if not user:
        raise RaiseEx(code=403, msg='Something Wrong. No data')

    if not check_password_hash(user.cu_passwd, passwd):
        raise RaiseEx(code=403, msg='Something Wrong. No data')

    if not user.cu_enable:
        raise RaiseEx(code=409, msg='User is disable')

    return user
