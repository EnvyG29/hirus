# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy.dialects import postgresql as psql

from ....lib.Db import TblBase

class Modules(TblBase):
    __tablename__ = 'modules'
    __table_args__ = {'schema': 'core'}

    cm_meta = Column(psql.JSONB(), nullable=False, default='{}')
