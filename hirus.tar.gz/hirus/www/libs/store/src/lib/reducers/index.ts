// export * from './app/upload.reducer';

export * from './auth/auth.reducer';
export * from './core/core.reducer';
