# -*- coding: utf-8 -*-

from pydantic import BaseModel
from pydantic import Field

class TokenData(BaseModel):
    ws: bool = Field(False, description='Token Type Auth/Ws')
    user_id: int = Field(..., description='User ID')
    is_padm: bool = Field(False, description='Platform Administrar')
