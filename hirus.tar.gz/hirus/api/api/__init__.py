# -*- coding: utf-8 -*-

# Import system Dependencies
import logging

from fastapi import Request

from fastapi.encoders import jsonable_encoder
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exception_handlers import RequestValidationError

from starlette.exceptions import HTTPException
from marshmallow import ValidationError

from .common.schema.Response import Errors
from .common.schema.Response import ErrorResponseException
from .common.schema.Response import error_response

from .app import app

# Socket IO
from .lib.Ws import asgi
from .lib.Ws import sio

from .modules.core import router as core_router

from cfg.api import config as cfg

log = logging.getLogger('api.main')

app.add_middleware(
    CORSMiddleware,
    # allow_origins=['*'],
    allow_methods=['*'],
    allow_headers=['*'],
    allow_credentials=True
)

app.mount('/ws', asgi)

# Core Routers
api_prefix = '{}/v{}'.format(cfg.API_PREFIX, cfg.API_VER)
app.include_router(core_router, prefix='{}/{}'.format(api_prefix, 'core'))

@app.exception_handler(HTTPException)
async def custom_http_exception_handler(request: Request, exc: HTTPException):
    """ Global requests exception handler. """

    return error_response(exc.status_code, Errors.request, err_data=exc.detail)


@app.exception_handler(RequestValidationError)
async def request_validation_exception_handler(request: Request, exc: RequestValidationError):
    """ Validation exception handler """

    return error_response(422, Errors.validation, err_data=jsonable_encoder(exc.errors()))


@app.exception_handler(ValidationError)
async def request_validation_exception_handler(request: Request, exc: ValidationError):
    """ Marshmallow validation exception handler """

    return error_response(422, Errors.validation, err_data=jsonable_encoder(exc.messages))


@app.exception_handler(ErrorResponseException)
async def response_exception_handler(request: Request, exc: ErrorResponseException):
    """ Handle custom ErrorResponseException exception """

    return exc.response

@app.exception_handler(Exception)
def exception_handler(request: Request, exc: Exception):
    """ Global requests exception handler. """

    err = f"{exc.__class__.__name__}: {exc}" if cfg.DEBUG_RESPONSES else "Internal Server Error"
    return error_response(500, Errors.api, err_data=err)

@app.on_event('startup')
async def startup():
    log.info('Start app')


@app.on_event('shutdown')
async def shutdown():
    log.info('Shutdown app')
