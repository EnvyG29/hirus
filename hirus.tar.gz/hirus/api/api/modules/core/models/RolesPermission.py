# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy import ForeignKey
from sqlalchemy.dialects import postgresql as psql

from .Roles import Roles
from .Permissions import Permissions

from ....lib.Db import TblBase

class RolesPermission(TblBase):
    __tablename__ = 'roles_permission'
    __table_args__ = {'schema': 'core'}

    crp_cr_id = Column(psql.INTEGER, ForeignKey(Roles.id), nullable=False)
    crp_cp_id = Column(psql.INTEGER, ForeignKey(Permissions.id), nullable=False)
