import { Component, Input } from '@angular/core';
import { DropdownModel } from './model/dropdown.model';

@Component({
  selector: 'mn-dropdown',
  templateUrl: 'dropdown.component.html',
  styleUrls: ['dropdown.component.scss']
})
export class DropdownComponent {
  @Input() data: DropdownModel[] = [];
  @Input() buttonClasses: 'p-2';
  @Input() dropdownRight = false;
  @Input() dropdownCenter = false;
  @Input() isCaretShown = true;
  @Input() itemClasses: 'static';
  @Input() hoverEnabled = false;
  @Input() label = 'Label';
  @Input() listClasses: 'p-2 bg-white';
  @Input() labelIcon: string | string[];
  @Input() colsEnabled = false;
  @Input() cols = 3;
  @Input() rows: number;
  @Input() flow: 'horizontal' | 'vertical' = 'horizontal';

  isOpen = false;
  timer: any = null;

  toggle() {
    if (!this.hoverEnabled) {
      this.isOpen = !this.isOpen;
    }
  }

  show() {
    if (this.hoverEnabled) {
      if (this.timer) {
        clearInterval(this.timer)
      }
      this.isOpen = true;
    }
  }

  hide() {
    if (this.hoverEnabled) {
      this.timer = setTimeout(() => {
        this.isOpen = false;
      }, 250)
    }
  }
}
