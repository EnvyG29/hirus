import { FormControl } from "@angular/forms";

export function createDaDataValidator(val) {
  return (c: FormControl) => {
    const err = {
      rangeError: {
        given: c.value,
        expected: val
      }
    }

    return (c.value !== val) ? err : null;
  };
}
