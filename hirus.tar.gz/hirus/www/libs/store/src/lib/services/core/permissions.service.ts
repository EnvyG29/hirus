import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment as env } from '@mn/environments';

import { PermResponse } from '../../models';

@Injectable({
  providedIn: 'root'
})
export class PermissionsService {
  constructor(
    private http: HttpClient
  ) {}

  getPermissions(pid: number) {
    return this.http.get<PermResponse>(`${env.api}/core/permissions/${pid}/`);
  }
}
