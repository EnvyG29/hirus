export interface NestedItems {
  id?: number;
  lvl?: number;
  meta: any;
  child?: NestedItems[];
}
