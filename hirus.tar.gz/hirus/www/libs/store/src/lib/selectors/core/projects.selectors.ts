import { createSelector, createFeatureSelector } from '@ngrx/store';

import {
  CoreState,
  ProjItem
} from '../../models';

import { coreNode } from '../../reducers';

export const projectsFeatures = createFeatureSelector<CoreState>(coreNode);

export const getAllProjects = createSelector(
  projectsFeatures,
  (state: CoreState): ProjItem[] => state.projects
)
