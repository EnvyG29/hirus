import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import {
  AppState,
  authActions
} from '@mn/store';

@Component({
  selector: 'vcp-auth-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  authForm: FormGroup;

  constructor(
    private store: Store<AppState>,
    private fb: FormBuilder
  ) {
    this.authForm = this.fb.group({
      username: [null, [Validators.required, Validators.minLength(8)]],
      password: [null, [Validators.required, Validators.minLength(8)]]
    });
  }

  ngOnInit(): void {
  }

  doSignIn(event: Event) {
    event.stopPropagation();

    if (this.authForm.valid) {
      this.store.dispatch(authActions.SignIn({ payload: this.authForm.value }))
    }
  }
}
