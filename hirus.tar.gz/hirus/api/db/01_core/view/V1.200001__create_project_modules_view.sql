------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Create: Date: 2018-12-07
-- Desc: Project Modules View
------------------------------------------------------------------------------------------------------------------------
DROP VIEW IF EXISTS "core"."project_modules_v";
CREATE VIEW "core"."project_modules_v" AS
SELECT
     cm."id"                                            AS "id"
    ,cm."cm_meta"                                       AS "cm_meta"
    ,cp."id"                                            AS "cp_id"
    ,coalesce(cpm."id", 0)                              AS "cpm_id"
    ,coalesce(cpm."cpm_cp_id", 0)                       AS "cpm_cp_id"
    ,coalesce(cpm."cpm_cm_id", 0)                       AS "cpm_cm_id"
    ,coalesce((cpm."cpm_cm_id" = cm."id"), FALSE)       AS "enabled"
FROM
    "core"."modules" AS "cm"
CROSS JOIN
    "core"."projects" AS "cp"
LEFT JOIN
    "core"."projects_modules" AS "cpm" ON cpm."cpm_cp_id" = cp."id" AND cm."id" = cpm."cpm_cm_id"
ORDER bY
    cm."id";
