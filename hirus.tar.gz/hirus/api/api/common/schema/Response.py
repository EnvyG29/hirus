# -*- coding: utf-8 -*-

from enum import Enum
from typing import Any
from typing import Type
from typing import TypeVar
from typing import Generic

from simplexml import dumps
from simplexml import loads

from starlette.requests import Request
from starlette.responses import Response
from starlette.responses import JSONResponse
from fastapi.encoders import jsonable_encoder

from pydantic import BaseModel
from pydantic import Field

T = TypeVar("T", bound=BaseModel)

class XmlResponse(Response):
    media_type = "text/xml"

    def render(self, content: Any) -> bytes:
        return dumps({'response': content}).encode("utf-8")

class XmlBody(Generic[T]):
    def __init__(self, model_class: Type[T]):
        self.model_class = model_class

    async def __call__(self, request: Request) -> T:
        if request.headers.get("Content-Type") == "application/xml":
            body = await request.body()
            dict_data = loads(body)
        else:
            dict_data = await request.json()

        return self.model_class.parse_obj(dict_data)

class Errors(str, Enum):
    validation = 'validation_error'
    request = 'request_error'
    auth = 'auth_error'
    api = 'api_error'

class ErrorResponseException(Exception):
    def __init__(self, response: JSONResponse):
        self._response = response

    @property
    def response(self) -> JSONResponse:
        return self._response

class ErrorPayload(BaseModel):
    scope: Errors = Field(None, description='Error Scope')
    msg: str = Field(None, description='Error message')

class SuccessResponse(BaseModel):
    success: bool = Field(True, const=True, description='Status')
    data: Any = Field(None, description='Success response Data')

class ErrorResponse(BaseModel):
    success: bool = Field(False, const=False, description='Status')
    data: ErrorPayload = Field(None, description='Error response Data')

def error_response(status: int, code: Errors, err_data: Any = None) -> JSONResponse:
    data = ErrorResponse(data=ErrorPayload(scope=code, msg=err_data))
    return JSONResponse(status_code=status, content=jsonable_encoder(data))

def success_response(status: int, resp_data: Any = None) -> JSONResponse:
    data = SuccessResponse(data=resp_data)
    return JSONResponse(status_code=status, content=jsonable_encoder(data))
