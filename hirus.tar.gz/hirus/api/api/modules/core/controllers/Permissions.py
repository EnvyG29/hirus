# -*- coding: utf-8 -*-

import logging

from fastapi import Body
from fastapi import Path
from fastapi import Depends
from fastapi.encoders import jsonable_encoder

from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession

from starlette.responses import JSONResponse

from ....common.depends.Auth import auth as dAuth
from ....common.depends.DbSession import get_db

from ....common.schema.TokenData import TokenData

from ....common.schema.Response import Errors
from ....common.schema.Response import ErrorResponse as sErrorResponse
from ....common.schema.Response import error_response

# from ..models.ProjectsModules import ProjectsModules as mProjectModules

from ..schemas.Permissions import Permissions as sPermissions

from ..services.Permissions import get_permissions

from .router import router

log = logging.getLogger('api.core.controller.permissions')

@router.get(
    '/permissions/{pid}/',
    response_model=sPermissions,
    responses={
        200: {'model': sPermissions},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse},
        403: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Permissions']
)
async def permissions_get(pid: int = Path(...), mn_sess: AsyncSession = Depends(get_db)):
    data = await get_permissions(pid=pid, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sPermissions(data=data)))
