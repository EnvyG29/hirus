# -*- coding: utf-8 -*-

from typing import List
from typing import Optional

from pydantic import BaseModel
from pydantic import Field

class Login(BaseModel):
    username: str = Field(..., description='Login')
    password: str = Field(..., description='Password')

class ProjectModulesChange(BaseModel):
    pid: int = Field(..., description='Project ID')
    mid: int = Field(..., description='Module ID')
    status: bool = Field(..., description='Module Status')

class TreeIcon(BaseModel):
    type: str = Field(..., description='Icon Type must (fa|img)')
    font: Optional[str] = Field(..., description='Icon Font must (fas|far|fab) only if "type" == "fa"')
    iname: Optional[str] = Field(..., description='Icon Name only if "type" == "fa"')
    path: Optional[str] = Field(..., description='Icon Path only if "type" == "img"')

class AddEditRole(BaseModel):
    id: Optional[int] = Field(..., description='Role ID (Required if Action Edit)')
    pid: Optional[int] = Field(..., description='Parent Role ID (Required if Action Add)')
    name: str = Field(..., description='Role Name')
    desc: str = Field(..., description='Role Description')
    icon: TreeIcon = Field(..., description='Role Icon')

class AddEditProject(BaseModel):
    id: Optional[int] = Field(..., description='Project ID (Required if Action Edit)')
    pid: Optional[int] = Field(..., description='Parent Project ID (Required if Action Add)')
    name: str = Field(..., description='Project Name')
    desc: str = Field(..., description='Project Description')
    icon: TreeIcon = Field(..., description='Project Icon')
