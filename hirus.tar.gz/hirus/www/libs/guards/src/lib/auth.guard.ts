import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';

import {
  CanActivate,
  CanActivateChild,
  Router,
  RouterStateSnapshot,
  ActivatedRouteSnapshot
} from '@angular/router';

import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';

import { AppState } from '@mn/store';
import { isLoggedIn } from '@mn/store';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(
    private store: Store<AppState>,
    private router: Router
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.store.pipe(
      select(isLoggedIn),
      map(auth =>{
        if (!auth) {
          this.router.navigate(['/auth', 'login'])
          return false
        } else {
          return true
        }
      }), take(1)
    );
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.canActivate(route, state)
  }
}

