# -*- coding: utf-8 -*-

from sqlalchemy.ext.asyncio import AsyncSession

from ...lib.Db import sess_api

async def get_db() -> AsyncSession:
    async with sess_api() as api_sess:
        yield api_sess
