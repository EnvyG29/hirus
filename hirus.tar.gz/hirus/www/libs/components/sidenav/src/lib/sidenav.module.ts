import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { SidenavComponent as Sidenav } from './sidenav.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,

    FontAwesomeModule
  ],
  exports: [
    Sidenav
  ],
  declarations: [
    Sidenav
  ]
})
export class SidenavModule {}
