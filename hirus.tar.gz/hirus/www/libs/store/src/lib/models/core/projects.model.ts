import { ApiResponse } from '@mn/store';
import { NestedItems } from '@mn/components/hchart';

export interface ProjAddEditPayload {
  id?: number;
  pid?: number;
  name: string;
  desc: string;
  icon: {
    type: 'fa' | 'img';
    font?: 'fas' | 'fab' | 'far';
    path?: string;
    iname?: string;
  };
}

export interface ProjItem extends NestedItems {
  meta: {
    name: string;
    desc: string;
    icon: {
      type: 'fa' | 'img',
      val: string[] | string;
    };
  };
  child?: ProjItem[];
}

export interface ProjResponse extends ApiResponse {
  data: ProjItem[];
}
