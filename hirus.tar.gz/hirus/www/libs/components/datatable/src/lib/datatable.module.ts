import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { PipesModule } from '@mn/pipes';

import { DragulaModule } from 'ng2-dragula';

import { LegacyComponent as DtLegacyComponent } from './legacy/legacy.component';
import { GroupComponent as DtGroupComponent } from './group/group.component';
import { TreeComponent as DtTreeComponent } from './tree/tree.component';
import { NodeComponent as DtTreeNodeComponent } from "./tree/node/node.component";

import {
  ColumnDirective,
  HeaderDirective
} from './directives/datatable.directive';

@NgModule({
  imports: [
    CommonModule,
    FontAwesomeModule,

    DragulaModule.forRoot(),

    PipesModule
  ],
  exports: [
    DtLegacyComponent,
    DtGroupComponent,
    DtTreeComponent,
    DtTreeNodeComponent,

    ColumnDirective,
    HeaderDirective
  ],
  declarations: [
    DtLegacyComponent,
    DtGroupComponent,
    DtTreeComponent,
    DtTreeNodeComponent,

    ColumnDirective,
    HeaderDirective
  ]
})
export class DatatableModule {}
