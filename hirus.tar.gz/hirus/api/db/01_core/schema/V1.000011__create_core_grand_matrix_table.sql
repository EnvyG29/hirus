------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Create: Date: 2019-01-21
-- Desc: acl_matrix
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."acl_matrix_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."acl_matrix" (
     "id"                       INTEGER NOT NULL DEFAULT nextval('core.acl_matrix_id_seq'::REGCLASS)
    ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"cam_cp_id"                INTEGER NOT NULL REFERENCES "core"."projects" ("id") ON DELETE CASCADE ON UPDATE CASCADE
    ,"cam_cu_id"                INTEGER NOT NULL REFERENCES "core"."users" ("id") ON DELETE CASCADE ON UPDATE CASCADE
    ,"cam_matrix"               JSONB NOT NULL DEFAULT '{}'
    ,PRIMARY KEY ("id")
);
ALTER SEQUENCE "core"."acl_matrix_id_seq" OWNED BY "core"."acl_matrix"."id";

-- Comment
COMMENT ON TABLE "core"."acl_matrix" IS 'Users acl_matrix';
COMMENT ON COLUMN "core"."acl_matrix"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."acl_matrix"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."acl_matrix"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."acl_matrix"."cam_cp_id" IS 'Link to core.projects table';
COMMENT ON COLUMN "core"."acl_matrix"."cam_cu_id" IS 'Link to core.users table';
COMMENT ON COLUMN "core"."acl_matrix"."cam_matrix" IS 'acl Matrix';
