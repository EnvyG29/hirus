import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CarouselComponent as Carousel } from './carousel.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';


@NgModule({
  imports: [
    CommonModule,
    FontAwesomeModule
  ],
  declarations: [
    Carousel
  ],
  exports: [
    Carousel
  ]
})
export class CarouselModule {}
