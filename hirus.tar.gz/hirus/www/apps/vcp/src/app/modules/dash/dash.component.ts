import { Component, OnInit } from '@angular/core';

import { WsService } from '@mn/store';

@Component({
  selector: 'vcp-dash',
  templateUrl: './dash.component.html',
  styleUrls: ['./dash.component.scss']
})
export class DashComponent implements OnInit {

  constructor(
    private ws: WsService
  ) { }

  ngOnInit(): void {
    this.ws.doMsg('job').subscribe(
      data => {
      }
    );
  }

  doTaskSend(event: Event) {
    event.stopPropagation();

    const data = {
      event: 'vcp.core.Test',
      queue: 'vcp.tasks',
      payload: {
        test: 'Test'
      }
    };

    this.ws.doSend('job', data);
  }
}
