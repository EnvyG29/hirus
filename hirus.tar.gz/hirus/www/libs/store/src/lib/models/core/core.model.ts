import {
  Module as ModuleItem,
  ProjItem,
  RoleItem,
  PermItem,
  WbConfig
} from '../../models';

export interface CoreState {
  currProj: number;
  currPerm: number;
  modules: ModuleItem[];
  roles: RoleItem;
  permissions: PermItem[];
  projects: ProjItem[];
  wb: WbConfig;
}
