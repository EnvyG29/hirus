# -*- coding: utf-8 -*-

import logging

from sqlalchemy import select
from sqlalchemy import update
from sqlalchemy import delete

from sqlalchemy import and_
from sqlalchemy import case
from sqlalchemy.ext.asyncio import AsyncSession

from ..schemas.Payloads import AddEditRole as pAddEditRole

from ..models.Roles import Roles as mRoles

log = logging.getLogger('api.core.service.roles')

async def _get_roles(nid: int = None, pid: int = None, sess: AsyncSession = None):
    if nid is None:
        r_tmp = await sess.execute(
            select(mRoles)
            .filter(
                mRoles.cr_cp_id == pid
            )
            .order_by(mRoles.lkey)
        )

        r_data = r_tmp.scalars().first()

    if nid is not None:
        r_tmp = await sess.execute(
            select(mRoles)
            .filter(
                mRoles.id == nid
            )
            .order_by(mRoles.lkey)
        )

        r_data = r_tmp.scalars().first()

        if (r_data.rkey - r_data.lkey) > 1:
            t_data = await sess.execute(
                select(mRoles)
                .filter(
                    and_(
                        mRoles.cr_cp_id == pid,
                        mRoles.lkey > r_data.lkey,
                        mRoles.rkey < r_data.rkey,
                        mRoles.lvl == r_data.lvl + 1
                    )
                ).order_by(mRoles.lkey)
            )

            return t_data.scalars().all()

    if (r_data.rkey - r_data.lkey) > 1 and r_data.lvl == 0:
        return [r_data]

    return r_data

async def _build_roles(nid: int = None, pid: int = None, sess: AsyncSession = None):
    roles = []

    data = await _get_roles(nid=nid, pid=pid, sess=sess)

    for item in data:
        if (item.rkey - item.lkey) > 1:
            chld = await _build_roles(nid=item.id, pid=pid, sess=sess)
            item.child = chld

        roles.append(item)

    return roles

async def get_roles(pid: int, sess: AsyncSession):
    tree = await _build_roles(pid=pid, sess=sess)

    return tree

async def add_role(req: pAddEditRole, sess: AsyncSession):
    t_icon = mRoles.build_icon(i_body=req.icon)
    t_par = await sess.execute(
        select(mRoles)
        .filter(
            mRoles.id == req.pid
        )
    )

    par = t_par.scalars().first()
    t_rkey = par.rkey

    await sess.execute(
        update(mRoles)
        .where(
            mRoles.rkey >= t_rkey,
            mRoles.cr_cp_id == par.cr_cp_id
        )
        .values(
            lkey=case([
                (mRoles.lkey > t_rkey, mRoles.lkey + 2)
            ], else_=mRoles.lkey),
            rkey=case([
                (mRoles.rkey >= t_rkey, mRoles.rkey + 2)
            ], else_=mRoles.rkey)
        )
    )
    await sess.commit()

    i_role = mRoles(
        cr_cp_id=par.cr_cp_id,
        lkey=t_rkey,
        rkey=t_rkey + 1,
        lvl=par.lvl + 1,
        meta={
            'name': req.name,
            'desc': req.desc,
            'icon': t_icon
        }
    )
    sess.add(i_role)
    await sess.commit()

    tree = await _build_roles(pid=par.cr_cp_id, sess=sess)
    return tree

async def update_role(pid: int, req: pAddEditRole, sess: AsyncSession):
    t_icon = mRoles.build_icon(i_body=req.icon)

    await sess.execute(
        update(mRoles)
        .where(
            mRoles.id == req.id,
            mRoles.cr_cp_id == pid
        )
        .values(
            meta={
                'name': req.name,
                'desc': req.desc,
                'icon': t_icon
            }
        )
    )
    await sess.commit()

    tree = await _build_roles(pid=pid, sess=sess)
    return tree

async def delete_role(pid: int, rid: int, sess: AsyncSession):
    d_tmp = await sess.execute(
        select(mRoles)
        .filter(
            mRoles.id == rid,
            mRoles.cr_cp_id == pid
        )
    )

    p_tmp = d_tmp.scalars().first()
    delta = p_tmp.rkey - p_tmp.lkey + 1

    await sess.execute(
        delete(mRoles)
        .filter(
            and_(
                mRoles.lkey >= p_tmp.lkey,
                mRoles.rkey <= p_tmp.rkey,
                mRoles.cr_cp_id == pid
            )
        )
    )
    await sess.commit()

    await sess.execute(
        update(mRoles)
        .where(
            and_(
                mRoles.rkey >= p_tmp.rkey,
                mRoles.cr_cp_id == pid
            )
        )
        .values(
            lkey=case([
                (mRoles.lkey > p_tmp.lkey, mRoles.lkey - delta)
            ], else_=mRoles.lkey),
            rkey=case([
                (mRoles.rkey >= p_tmp.rkey, mRoles.rkey - delta)
            ], else_=mRoles.rkey)
        )
    )
    await sess.commit()

    tree = await _build_roles(pid=pid, sess=sess)
    return tree
