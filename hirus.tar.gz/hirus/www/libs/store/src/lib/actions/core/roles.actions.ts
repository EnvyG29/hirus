import { createAction, props } from '@ngrx/store';

import {
  RoleResponse,
  RoleAddEditPayload
} from '../../models';

export const GetRoles = createAction(
  '[App/Core] Get Project Roles'
)

export const GetRolesSuccess = createAction(
  '[Api/Core] Get Project Roles Success',
  props<{ payload: RoleResponse }>()
)

export const AddRole = createAction(
  '[App/Core] Add Role to Project',
  props<{ payload: RoleAddEditPayload }>()
)

export const EditRole = createAction(
  '[App/Core] Edit Project Role',
  props<{ payload: RoleAddEditPayload }>()
)

export const DeleteRole = createAction(
  '[App/Core] Delete Role from Project',
  props<{ rid: number }>()
)

export const rolesActions = {
  GetRoles,
  GetRolesSuccess,
  AddRole,
  EditRole,
  DeleteRole
}
