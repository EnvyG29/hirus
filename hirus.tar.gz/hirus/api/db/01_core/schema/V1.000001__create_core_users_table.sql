------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Schema: core
-- Create: Date: 2019-11-13
------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------
-- Desc: Create core.users table
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."users_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."users" (
   "id"                       INTEGER NOT NULL DEFAULT nextval('core.users_id_seq'::REGCLASS)
  ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  ,"cu_passwd"                CHARACTER VARYING (255) NOT NULL
  ,"cu_profile"               JSONB NOT NULL
  ,"cu_padm"                  BOOLEAN NOT NULL DEFAULT FALSE
  ,"cu_enable"                BOOLEAN NOT NULL DEFAULT TRUE
  ,PRIMARY KEY ("id")
);
ALTER SEQUENCE "core"."users_id_seq" OWNED BY "core"."users"."id";

-- Comment
COMMENT ON TABLE "core"."users" IS 'Registred users';
COMMENT ON COLUMN "core"."users"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."users"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."users"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."users"."cu_passwd" IS 'User Password';
COMMENT ON COLUMN "core"."users"."cu_profile" IS 'User info (first name, last name, etc...)';
COMMENT ON COLUMN "core"."users"."cu_padm" IS 'Main platform Adminstrator';
COMMENT ON COLUMN "core"."users"."cu_enable" IS 'Enable|Disable Users';

/*
------------------------------------------------------------------------------------------------------------------------
-- Desc: cu_profile structure
------------------------------------------------------------------------------------------------------------------------
{
    "credentials": {
        "email": "string",
        "tel": "string"
    },
    "profile": {
        "name": {
            "first": "string",
            "last": "string",
            "sur": "string"
        },
        "aditional": {
            "tel": [],
            "email": []
        },
        "oauth": [{
            "<prov>": {
                <prov_data>
            }
        }]
    }
}

{
  "balance": 0.00,
  "profile": {
    "name": {
      "sur": "V.",
      "last": "Semenets",
      "first": "Pavel"
    },
    "oauth": [],
    "aditional": {
      "tel": [],
      "email": []
    }
  },
  "credentials": {
    "tel": "79671845054",
    "email": "darkman@meganet.ru"
  }
}
*/

