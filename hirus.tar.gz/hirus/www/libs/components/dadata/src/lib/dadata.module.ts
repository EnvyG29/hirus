import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";

import { DadataComponent } from "./dadata.component";

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    DadataComponent
  ],
  declarations: [
    DadataComponent
  ]
})
export class DadataModule {}
