# -*- coding: utf-8 -*-

import logging

from fastapi import Body
from fastapi import Path
from fastapi import Depends
from fastapi.encoders import jsonable_encoder

from sqlalchemy.ext.asyncio import AsyncSession
from ....common.depends.DbSession import get_db

from starlette.responses import JSONResponse

from ....common.depends.Auth import auth as dAuth
from ....common.schema.Response import ErrorResponse as sErrorResponse

from ..schemas.Projects import Projects as sProjects
from ..schemas.Payloads import AddEditProject as pAddEditProject

from ..services.Projects import get_projects
from ..services.Projects import add_project
from ..services.Projects import update_project
from ..services.Projects import delete_project

from .router import router

log = logging.getLogger('api.core.controller.projects')

@router.get(
    '/projects/',
    response_model=sProjects,
    responses={
        200: {'model': sProjects},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Projects']
)
async def projects_get(mn_sess: AsyncSession = Depends(get_db)):
    data: sProjects = await get_projects(sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sProjects(data=data)))

@router.post(
    '/projects/',
    response_model=sProjects,
    responses={
        200: {'model': sProjects},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Projects']
)
async def projects_post(req: pAddEditProject = Body(...), mn_sess: AsyncSession = Depends(get_db)):
    data: sProjects = await add_project(req=req, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sProjects(data=data)))

@router.put(
    '/projects/',
    response_model=sProjects,
    responses={
        200: {'model': sProjects},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Projects']
)
async def projects_put(req: pAddEditProject = Body(...), mn_sess: AsyncSession = Depends(get_db)):
    data: sProjects = await update_project(req=req, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sProjects(data=data)))

@router.delete(
    '/projects/{pid}/',
    response_model=sProjects,
    responses={
        200: {'model': sProjects},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Projects']
)
async def projects_del(pid: int = Path(...), mn_sess: AsyncSession = Depends(get_db)):
    data: sProjects = await delete_project(pid=pid, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sProjects(data=data)))
