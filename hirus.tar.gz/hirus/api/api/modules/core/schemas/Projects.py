# -*- coding: utf-8 -*-
from typing import List
from typing import Optional
from pydantic import BaseModel

from ....common.schema.TblBase import TblBase
from ....common.schema.Response import SuccessResponse

class ProjectIcon(BaseModel):
    type: str
    val: List[str]

class ProjectMeta(BaseModel):
    name: str
    desc: str
    icon: ProjectIcon

class ProjectData(TblBase):
    lkey: int
    rkey: int
    lvl: int
    meta: Optional[ProjectMeta]
    cp_enable: bool
    child: Optional[List['ProjectData']] = None

    class Config:
        orm_mode = True

ProjectData.update_forward_refs()

class Projects(SuccessResponse):
    data: List[ProjectData]

    class Config:
        arbitrary_types_allowed = True
