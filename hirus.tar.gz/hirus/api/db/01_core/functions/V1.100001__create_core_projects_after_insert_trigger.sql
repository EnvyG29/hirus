------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Schema: core
-- Create: Date: 2020-07-09
------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------
-- Desc: Create core projects table trigger
------------------------------------------------------------------------------------------------------------------------
--
-- Create Function
--
CREATE OR REPLACE FUNCTION "core"."projects_ftr"() RETURNS TRIGGER AS
$$
DECLARE
    def_col     JSONB := '[{"max": 0, "tag": "n", "label": "Pending", "order": 1, "protected": true}, {"max": 0, "tag": "d", "label": "Done", "order": 99, "protected": true}]';
    def_badge   JSONB := '[{"tag": "fr", "label": "Feature request", "protected": true}, {"tag": "bug", "label": "Bug", "protected": true}, {"tag": "sp", "label": "Service problem", "protected": false}]';
    def_prio    JSONB := '[{"tag": "def", "label": "Default", "color": "info", "protected": true}, {"tag": "high", "label": "High", "color": "danger", "protected": true}, {"tag": "low", "label": "Low", "color": "secondary", "protected": true}]';
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO "kanban".workboards (
            kw_cp_id,
            kw_cols,
            kw_badge,
            kw_prio
        ) VALUES (
            NEW.id,
            def_col,
            def_badge,
            def_prio
        );
        RETURN NEW;
    END IF;
END
$$
LANGUAGE 'plpgsql';

--
-- Create Trigger
--
CREATE TRIGGER "after_insert_projects_tr" AFTER INSERT ON "core"."projects" FOR EACH ROW EXECUTE PROCEDURE "core"."projects_ftr"();
