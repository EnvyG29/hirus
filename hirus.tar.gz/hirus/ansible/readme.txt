[Планирование]
doc01.hirus.ru - 10.6.0.71 - Master (Leader)
doc02.hirus.ru - 10.6.0.72 - Worker 01 (NodeExporter, Drone-Runner)
doc03.hirus.ru - 10.6.0.73 - Worker 02 (NodeExporter, Drone-Runner)
doc04.hirus.ru - 10.6.0.74 - Worker 03 (NodeExporter, Drone-Runner)
nfs.hirus.ru - 10.6.0.75 - Shared Storage

[DNS Имена для кластера swarm]
ing - Ingress Proxy (Traefik)
swp - Swarmpit
git - Gitea
ci - Drone-Ci
yt - Youtrack
mon - Grafana

[Users]
login: tech
pass: **********


# Tokens
youtrack - *****************

