import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { BreadcrumbComponent } from './breadcrumb.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,

    FontAwesomeModule
  ],
  exports: [
    BreadcrumbComponent
  ],
  declarations: [BreadcrumbComponent]
})
export class BreadcrumbModule { }
