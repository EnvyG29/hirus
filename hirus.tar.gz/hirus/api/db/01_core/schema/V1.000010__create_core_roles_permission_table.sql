------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Create: Date: 2018-12-07
-- Desc: Link Roles and Permissions
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."roles_permission_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."roles_permission" (
   "id"                       INTEGER NOT NULL DEFAULT nextval('core.roles_permission_id_seq'::REGCLASS)
  ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
  ,"crp_cr_id"                INTEGER NOT NULL REFERENCES "core"."roles" ("id") ON DELETE CASCADE
  ,"crp_cp_id"                INTEGER NOT NULL REFERENCES "core"."permissions" ("id") ON DELETE CASCADE
  ,PRIMARY KEY ("id")
);
ALTER SEQUENCE "core"."roles_permission_id_seq" OWNED BY "core"."roles_permission"."id";

-- Comment
COMMENT ON TABLE "core"."roles_permission" IS 'Registred our roles_permission';
COMMENT ON COLUMN "core"."roles_permission"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."roles_permission"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."roles_permission"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."roles_permission"."crp_cr_id" IS 'Link to core.roles table';
COMMENT ON COLUMN "core"."roles_permission"."crp_cp_id" IS 'Link to core.permissions table';

/*
------------------------------------------------------------------------------------------------------------------------
-- Views
------------------------------------------------------------------------------------------------------------------------
DROP VIEW IF EXISTS "core"."roles_permission_v";
CREATE VIEW "core"."roles_permission_v" AS
  SELECT
     sp."id"                                            AS "id"
    ,sp."sp_sc_id"                                      AS "sp_sc_id"
    ,sp."sp_name"                                       AS "sp_name"
    ,sp."sp_desc"                                       AS "sp_desc"
    ,sr."id"                                            AS "sr_id"
    ,coalesce(srp."id", 0)                              AS "srp_id"
    ,coalesce(srp."srp_sr_id", 0)                       AS "srp_sr_id"
    ,coalesce(srp."srp_sp_id", 0)                       AS "srp_sp_id"
    ,coalesce((srp."srp_sr_id" = sr."id"), FALSE)       AS "enabled"
  FROM
    "core"."permissions" AS "sp"
  CROSS JOIN
    "core"."roles" AS "sr"
  LEFT JOIN
    "core"."roles_permission" AS "srp" ON srp."srp_sp_id" = sp."id" AND sr."id" = srp."srp_sr_id"
  ORDER BY
    "sp"."id";
*/