# -*- coding: utf-8 -*-

import logging

from fastapi import Body
from fastapi import Path
from fastapi import Depends
from fastapi.encoders import jsonable_encoder

from sqlalchemy.ext.asyncio import AsyncSession
from ....common.depends.DbSession import get_db

from starlette.responses import JSONResponse

from ..schemas.Roles import Roles as sRoles

from ....common.depends.Auth import auth as dAuth
from ....common.schema.Response import ErrorResponse as sErrorResponse

from ..schemas.Payloads import AddEditRole as pAddEditRole

from ..services.Roles import get_roles
from ..services.Roles import add_role
from ..services.Roles import update_role
from ..services.Roles import delete_role

from .router import router

log = logging.getLogger('api.core.controller.roles')

@router.get(
    '/roles/{pid}/',
    response_model=sRoles,
    responses={
        200: {'model': sRoles},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Roles']
)
async def roles_get(pid: int = Path(...), mn_sess: AsyncSession = Depends(get_db)):
    data: sRoles = await get_roles(pid=pid, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sRoles(data=data[0])))

@router.post(
    '/roles/',
    response_model=sRoles,
    responses={
        200: {'model': sRoles},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Roles']
)
async def roles_post(req: pAddEditRole = Body(...), mn_sess: AsyncSession = Depends(get_db)):
    data: sRoles = await add_role(req=req, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sRoles(data=data[0])))

@router.put(
    '/roles/{pid}/',
    response_model=sRoles,
    responses={
        200: {'model': sRoles},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Roles']
)
async def roles_put(pid: int = Path(...), req: pAddEditRole = Body(...), mn_sess: AsyncSession = Depends(get_db)):
    data: sRoles = await update_role(pid=pid, req=req, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sRoles(data=data[0])))

@router.delete(
    '/roles/{pid}/{rid}/',
    response_model=sRoles,
    responses={
        200: {'model': sRoles},
        400: {'model': sErrorResponse},
        401: {'model': sErrorResponse}
    },
    dependencies=[Depends(dAuth)],
    tags=['Core/Roles']
)
async def roles_del(pid: int = Path(...), rid: int = Path(...), mn_sess: AsyncSession = Depends(get_db)):
    data: sRoles = await delete_role(pid=pid, rid=rid, sess=mn_sess)

    return JSONResponse(content=jsonable_encoder(sRoles(data=data[0])))
