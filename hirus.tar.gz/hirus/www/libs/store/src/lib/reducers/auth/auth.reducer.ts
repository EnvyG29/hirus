import { createReducer, on } from '@ngrx/store';

import { AuthState } from '../../models';
import { authActions } from '../../actions';


export const authNode = 'auth';

export const initialAuthState: AuthState = {
  handling: false,
  isLoggedIn: false,
  user: undefined
}

export const authReducer = createReducer(
  initialAuthState,

  on(authActions.SignIn, (state) => {
    return {
      ...state,
      handling: true
    }
  }),

  on(authActions.SignInSuccess, (state, {payload}) => {
    return {
      ...state,
      handling: false,
      isLoggedIn: true,
      user: payload.data
    }
  }),

  on(authActions.SignInResore, (state, {payload}) => {
    return {
      ...state,
      isLoggedIn: true,
      user: payload
    }
  }),

  on(authActions.AuthTokenRefresh, (state) => {
    return {
      ...state,
      handling: true
    }
  }),

  on(authActions.AuthTokenRefreshSuccess, (state) => {
    return {
      ...state,
      handling: false
    }
  })
)
