import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { switchMap, map, tap  } from 'rxjs/operators';

import { authActions } from '@mn/store';

import {
  AuthService,
  LsService
} from '@mn/store';

@Injectable({
  providedIn: 'root'
})
export class AuthEffects {
  constructor(
    private actions$: Actions,
    private router: Router,
    private aService: AuthService,
    private lService: LsService
  ) {
  }

  signIn$ = createEffect(() => this.actions$.pipe(
      ofType(authActions.SignIn),
      switchMap(action => this.aService.signIn(action.payload)
        .pipe(
          map(res => {
            this.lService.setItem('auth', res.data );
            return authActions.SignInSuccess({payload: res});
          })
        )
      )
  ));

  signRefresh$ = createEffect(() => this.actions$.pipe(
      ofType(authActions.AuthTokenRefresh),
      switchMap(() => this.aService.signRefresh()
        .pipe(
          map(res => {
            console.log(res);
            return authActions.AuthTokenRefreshSuccess();
          })
        )
      )
  ));

  signRefreshSuccess$ = createEffect(() => this.actions$.pipe(
    ofType(authActions.AuthTokenRefreshSuccess),
    tap(() => {
    })
  ), { dispatch: false });

  signInSuccess$ = createEffect(() => this.actions$.pipe(
    ofType(authActions.SignInSuccess),
    tap(() => {
      this.router.navigate(['']);
    })
  ), { dispatch: false });
}
