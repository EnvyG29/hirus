import { createSelector, createFeatureSelector } from '@ngrx/store';

import {
  CoreState,
  Module as ModuleItem
} from '../../models';

import { coreNode } from '../../reducers';

export const modulesFeatures = createFeatureSelector<CoreState>(coreNode);

export const getAllModules = createSelector(
  modulesFeatures,
  (state: CoreState): ModuleItem[] => state.modules
)
