# -*- coding: utf-8 -*-

from sqlalchemy import Column
from sqlalchemy.dialects import postgresql as psql

from ....lib.Db import TblBase

class Company(TblBase):
    __tablename__ = 'company'
    __table_args__ = {'schema': 'core'}

    cc_name = Column(psql.VARCHAR(128), nullable=False)
    cc_full = Column(psql.VARCHAR(255), nullable=False)
    cc_info = Column(psql.JSONB(), nullable=False, default='{}')
    cc_enable = Column(psql.BOOLEAN, nullable=False, default=True)
