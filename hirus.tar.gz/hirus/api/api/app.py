# -*- coding: utf-8 -*-

from fastapi import FastAPI

app = FastAPI(
    title="Mn-Api Server",
    docs_url=None,
    version='0.1.0'
)