import { Component, Input, OnInit } from '@angular/core';
import { animate, style, transition, trigger } from '@angular/animations'

import { WsService } from '@mn/store';

@Component({
  selector: 'vcp-wrapper-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss'],
  animations: [
    trigger('dd-menu', [
      transition(':enter', [
        style({
          opacity: '0'
        }),
        animate(100)
      ]),
      transition(':leave', [
        animate(100, style({
          opacity: '0'
        }))
      ])
    ])
  ]
})
export class LayoutComponent implements OnInit {
  openedMenu: string | null = null;
  @Input() authenticated: boolean = false;

  constructor(
    private ws: WsService
  ) {}

  ngOnInit(): void {
    if (this.authenticated) {
      this.ws.doGetToken().subscribe(
        res => {
          this.ws.wsInit('vcp', res.data.token);
        }
      );
    }
  }

  toggleMenu(val: string) {
    if (this.openedMenu !== val) {
      this.openedMenu = val;
    } else {
      this.openedMenu = null;
    }
  }
}
