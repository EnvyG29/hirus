import { createSelector, createFeatureSelector } from '@ngrx/store';

import {
  CoreState,
} from '../../models';

import { coreNode } from '../../reducers';

export const coreFeatures = createFeatureSelector<CoreState>(coreNode);

export const getCurrProj = createSelector(
  coreFeatures,
  (state: CoreState): number => state.currProj
)
