import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, BehaviorSubject } from 'rxjs';
import { Socket, io } from 'socket.io-client';

import { WsToken } from '../../models';
import { environment as env } from '@mn/environments';

@Injectable({
  providedIn: 'root'
})
export class WsService {
  private socket: Socket;
  private url: string = 'wss://hirus.ru';

  conn$ = new BehaviorSubject<boolean>(false);

  constructor(
    private http: HttpClient
  ) {
  }

  wsInit(ns: string, token: string) {
    // this.socket = io(`${this.url}/${ns}`,{
    //  transportOptions: {
    //    polling: {
    //      extraHeaders: {
    //        withCredentials: true
    //      }
    //    }
    //  }
    // });

    this.socket = io(`${this.url}/${ns}`, {
      path: '/ws/socket.io',
      query: { token: token }
    });

    this.socket.on('connect', () => this.conn$.next(true));
    this.socket.on('disconnect', () => this.conn$.next(false));
  }

  wsLeave() {
    this.socket.disconnect();
    this.conn$.next(false);
  }

  doGetToken(): Observable<WsToken> {
    return this.http.get<WsToken>(`${env.api}/core/login/`);
  }

  doSubscribe(chan: string) {
    this.conn$.subscribe(
      conn => {
        if (conn) {
          this.socket.emit('subscribe', {chan});
        }
      }
    );
  }

  doUnsubscribe(chan: string) {
    this.conn$.subscribe(
      conn => {
        if (conn) {
          this.socket.emit('unsubscribe', {chan});
        }
      }
    );
  }

  doSend(event: string, data?: any) {
    console.group();
    console.log('----- SOCKET OUTGOING -----');
    console.log('Action: ', event);
    console.log('Payload: ', data);
    console.groupEnd();

    this.socket.emit(event, data);
  }

  doMsg(event: string) {
    return new Observable(observer => {
      this.socket.on(event, (data: any) => {
        console.group();
        console.log('----- SOCKET INBOUND -----');
        console.log('Action: ', event);
        console.log('Payload: ', data);
        console.groupEnd();

        observer.next(data);
      });

      return () => this.socket.off(event);
    });
  }
}
