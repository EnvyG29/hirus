# -*- coding: utf-8 -*-

from .controllers import Login
from .controllers import Projects
from .controllers import Roles
from .controllers import Permissions
from .controllers import Modules
from .controllers import Upload

from .controllers.router import router
