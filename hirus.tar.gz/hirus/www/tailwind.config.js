const colors = require('tailwindcss/colors');
const plugin = require('tailwindcss/plugin');
const Color = require('color');
const darken = (clr, val) => Color(clr).darken(val).hex();
const lighten = (clr, val) => Color(clr).lighten(val).hex();

module.exports = {
  prefix: '',
  content: [
    './apps/awp/src/**/*.{html,ts}',
    './apps/parea/src/**/*.{html,ts}',
    './apps/site/src/**/*.{html,ts}',
    './apps/vcp/src/**/*.{html,ts}',
    './libs/**/*.{html,ts}',
  ],
  safelist: ['h-44'],
  theme: {
    extend: {
      animation: {
        'fade-in': 'fade-in ease-in 250ms;',
        failed: '2s ease-in-out infinite failed',
        prefail: '2s ease-in-out infinite prefail'
      },
      colors: {
        // Site variables
        fb: '#3b5999',
        tw: '#55acee',
        vk: '#4c75a3',
        docx: {
          DEFAULT: '#2a5699',
          darken: darken('#2a5699', 0.2),
        },
        pdf: {
          DEFAULT: '#F40F02',
          darken: darken('#f40f02', 0.2),
        },
        mn: {
          'dark-gray': '#49515e',
          green: {
            DEFAULT: '#6b9e42',
            lighten: lighten('#6b9e42', 0.2),
            darken: darken('#6b9e42', 0.2),
          },
          red: '#f13f23',
          blue: {
            DEFAULT: '#0088c2',
            darken: darken('#0088c2', 0.2),
          },
          'light-gray': '#f6f6f6',
        },

        // Vcp variables
        'blue-gray': colors.slate,
        'cool-gray': colors.gray,
        'true-gray': colors.neutral,
        'warm-gray': colors.stone,
        'light-blue': colors.sky,
        gray: colors.gray,
        red: colors.red,
        orange: colors.orange,
        amber: colors.amber,
        yellow: colors.yellow,
        lime: colors.lime,
        green: colors.green,
        emerald: colors.emerald,
        teal: colors.teal,
        cyan: colors.cyan,
        blue: colors.blue,
        indigo: colors.indigo,
        violet: colors.violet,
        purple: colors.violet,
        fuchsia: colors.fuchsia,
        pink: colors.pink,
        rose: colors.rose,
        black: colors.black,
        white: colors.white,
      },
      dropShadow: {
        custom: '0 0 5px black'
      },
      flex: {
        even: '1 1 0',
      },
      fontSize: {
        '2xs': ['0.625rem', '0.625rem']
      },
      gridTemplateRows: {
        '11': 'repeat(11, minmax(0, min-content))'
      },
      keyframes: {
        'fade-in': { from: { opacity: 0 }, to: { opacity: 1 } },
        'fade-out': { from: { opacity: 1 }, to: { opacity: 0 } },
        failed: {
          '0%, 100%': { color: 'black' },
          '50%': { color: 'red', textShadow: 'darkred 0 0 .125rem' }
        },
        prefail: {
          '0%, 100%': { color: 'black' },
          '50%': { color: 'orange', textShadow: 'darkorange 0 0 .125rem' }
        }
      },
      spacing: {
        '1/24': '4.166666%',
        '18': '4.5rem',
        '26rem': '26rem',
        '100': '100px',
        '150': '150px',
        '200': '200px',
        '250': '250px',
        '300': '300px',
        '350': '350px',
        '400': '400px',
        '450': '450px',
        '500': '500px',
        '550': '550px',
        '600': '600px',
        '650': '650px',
        '700': '700px',
        '750': '750px',
        '800': '800px',
        '850': '850px',
        '900': '900px',
        '950': '950px',
        '1000': '1000px',
        '1024': '1024px',
        '1280': '1280px'
      },
      minHeight: {
        '12': '3rem'
      },
      height: {
        'workboard': 'calc(100vh - 144px)',
      },
      width: {
        'desktop': '1200px',
      },
      aspectRatio: {},
      lineClamp: {},
    },
  },
  plugins: [
    plugin(({ addUtilities }) => {
      const newUtilities = {
        '.hide-scrollbar': {
          '-ms-overflow-style': 'none',
          scrollbarWidth: 'none'
        },
        '.hide-scrollbar::-webkit-scrollbar': {
          display: 'none'
        }
      }

      addUtilities(newUtilities, [])
    }),

    require('@tailwindcss/aspect-ratio'),
    require('@tailwindcss/line-clamp'),
    require('@tailwindcss/typography')
  ],
}
