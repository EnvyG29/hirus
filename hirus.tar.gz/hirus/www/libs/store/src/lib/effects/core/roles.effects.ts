import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';

import { map, withLatestFrom, mergeMap, switchMap } from 'rxjs/operators';

import { CoreState } from '@mn/store';
import { rolesActions } from '@mn/store';
import { getCurrProj } from '@mn/store';

import {
  RolesService
} from '@mn/store';

@Injectable({
  providedIn: 'root'
})
export class RolesEffects {
  constructor(
    private actions$: Actions,
    private rService: RolesService,
    private store: Store<CoreState>
  ) {
  }

  getRoles$ = createEffect(() => this.actions$.pipe(
    ofType(rolesActions.GetRoles),
    withLatestFrom(this.store.select(getCurrProj)),
    mergeMap(([action, pid]) => this.rService.getRoles(pid)
      .pipe(
        map(res => {
          return rolesActions.GetRolesSuccess({payload: res});
        })
      )
    )
  ));

  addRole$ = createEffect(() => this.actions$.pipe(
    ofType(rolesActions.AddRole),
    switchMap(action => this.rService.addRoles(action.payload)
      .pipe(
        map(res => {
          return rolesActions.GetRolesSuccess({payload: res});
        })
      )
    )
  ));

  editRole$ = createEffect(() => this.actions$.pipe(
    ofType(rolesActions.EditRole),
    withLatestFrom(this.store.select(getCurrProj)),
    mergeMap(([action, pid]) => this.rService.editRoles(pid, action.payload)
      .pipe(
        map(res => {
          return rolesActions.GetRolesSuccess({payload: res});
        })
      )
    )
  ));

  deleteRoles$ = createEffect(() => this.actions$.pipe(
    ofType(rolesActions.DeleteRole),
    withLatestFrom(this.store.select(getCurrProj)),
    mergeMap(([action, pid]) => this.rService.deleteRoles(pid, action.rid)
      .pipe(
        map(res => {
          return rolesActions.GetRolesSuccess({payload: res});
        })
      )
    )
  ));
}
