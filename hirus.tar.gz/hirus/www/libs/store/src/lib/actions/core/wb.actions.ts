import { createAction, props } from '@ngrx/store';

import {
  WbBadges,
  WbCols,
  WbConfigResponse, WbPrio
} from '../../models';

export const GetWbConfig = createAction(
  '[App/Core] Get Project Workboard Configuration'
)

export const GetWbConfigSuccess = createAction(
  '[Api/Core] Get Project Workboard Configuration Success',
  props<{ payload: WbConfigResponse }>()
)

export const AddWbCols = createAction(
  '[App/Core] Add Workboard Column',
  props<{ payload: WbCols }>()
)

export const EditWbCols = createAction(
  '[App/Core] Edit Workboard Column',
  props<{ payload: WbCols }>()
)

export const DelWbCols = createAction(
  '[App/Core] Delete Workboard Column',
  props<{ payload: WbCols }>()
)

export const AddWbBadge = createAction(
  '[App/Core] Add Workboard Badge',
  props<{ payload: WbBadges }>()
)

export const EditWbBadge = createAction(
  '[App/Core] Edit Workboard Badge',
  props<{ payload: WbBadges }>()
)

export const DelWbBadge = createAction(
  '[App/Core] Delete Workboard Badge',
  props<{ payload: WbBadges }>()
)

export const AddWbPrio = createAction(
  '[App/Core] Add Workboard Priority',
  props<{ payload: WbPrio }>()
)

export const EditWbPrio = createAction(
  '[App/Core] Edit Workboard Priority',
  props<{ payload: WbPrio }>()
)


export const DelWbPrio = createAction(
  '[App/Core] Delete Workboard Priority',
  props<{ payload: WbPrio }>()
)

export const ApplyWbColConfig = createAction(
  '[App/Core] Apply Wrokboard Column Configuration'
)

export const ApplyWbBadgeConfig = createAction(
  '[App/Core] Apply Wrokboard Badges Configuration'
)

export const ApplyWbPrioConfig = createAction(
  '[App/Core] Apply Wrokboard Ptiority Configuration'
)

export const wbActions = {
  GetWbConfig,
  GetWbConfigSuccess,
  AddWbCols,
  EditWbCols,
  DelWbCols,
  AddWbBadge,
  EditWbBadge,
  DelWbBadge,
  AddWbPrio,
  EditWbPrio,
  DelWbPrio,
  ApplyWbColConfig,
  ApplyWbBadgeConfig,
  ApplyWbPrioConfig
}
