import { Injectable } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { HttpHandler, HttpRequest, HttpInterceptor, HttpEvent, HttpErrorResponse } from '@angular/common/http';

import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, filter, finalize, map, switchMap, take } from 'rxjs/operators';

import { AppState } from '@mn/store';

import { isAuthHandling } from '@mn/store';
import { authActions } from '@mn/store';

@Injectable({
  providedIn: 'root'
})
export class ApiInterceptor implements HttpInterceptor {
  private refreshCookieInProgress = false;
  private refreshCookieSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor(
    private store: Store<AppState>
  ) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError(error => {
        if (error instanceof  HttpErrorResponse && error.status === 401 ) {
          if (this.refreshCookieInProgress) {
            console.log('In Progress')
            return this.refreshCookieSubject
              .pipe(
                filter(res => res !== null),
                take(1),
                switchMap(() => next.handle(this.afterCookieRefresh(req)))
              );
          } else {
            console.log('Run Refresh Action')
            this.refreshCookieInProgress = true;
            this.refreshCookieSubject.next(null);
            this.store.dispatch(authActions.AuthTokenRefresh());

            return this.refreshInProgress().pipe(
              switchMap((success: boolean) => {
                console.log('success');
                this.refreshCookieSubject.next(success);
                return next.handle(this.afterCookieRefresh(req));
              }),
              finalize(() => this.refreshCookieInProgress = false)
            )
          }
        } else {
          return throwError(error)
        }
      })
    );
  }

  private refreshInProgress(): Observable<boolean> {
    return this.store.pipe(select(isAuthHandling),
      map(handling => {
        console.log(handling);
        return handling
      }), take(1)
    );
  }

  private afterCookieRefresh(req: HttpRequest<any>): HttpRequest<any> {
    return req
  }
}
