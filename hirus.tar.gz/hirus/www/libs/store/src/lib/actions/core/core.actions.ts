import { createAction, props } from '@ngrx/store';

export const SetCurrProj = createAction(
  '[App/Core] Set Current Project',
  props<{ pid: number }>()
)

export const coreActions = {
  SetCurrProj
}
