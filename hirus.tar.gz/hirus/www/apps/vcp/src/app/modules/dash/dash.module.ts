import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { DashRouting } from './dash.routing';
import { DashComponent } from './dash.component';
import { CardComponent } from './card/card.component';

@NgModule({
  imports: [
    CommonModule,
    FontAwesomeModule,

    DashRouting
  ],
  declarations: [
    DashComponent,
    CardComponent
  ]
})
export class DashModule { }
