# -*- coding: utf-8 -*-

from typing import List
from typing import Optional
from pydantic import BaseModel

from ....common.schema.TblBase import TblBase
from ....common.schema.Response import SuccessResponse

from .Modules import ModuleCtl

class PermItem(TblBase):
    cp_name: str
    cp_desc: str
    cp_data: List[ModuleCtl]

    class Config:
        orm_mode = True

class Permissions(SuccessResponse):
    data: List[PermItem]

    class Config:
        arbitrary_types_allowed = True
