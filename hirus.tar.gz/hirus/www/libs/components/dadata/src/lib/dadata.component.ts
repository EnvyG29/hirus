import {
  Component,
  ElementRef,
  EventEmitter,
  forwardRef,
  HostListener,
  Inject,
  Input,
  OnChanges,
  OnInit,
  Output,
  Renderer2,
  SimpleChanges,
  ViewChild
} from "@angular/core";

import { DOCUMENT } from "@angular/common";

import {
  FormControl,
  ControlValueAccessor,
  NG_VALIDATORS,
  NG_VALUE_ACCESSOR
} from "@angular/forms";

import { Subject, timer } from "rxjs";
import { debounce } from "rxjs/operators";

import { unwrapHtmlForSink } from "safevalues";
import { createHtml } from "safevalues/implementation/html_impl";

import { createDaDataValidator } from "./validators/dadata.validators";
import { DadataType } from "./enums/dadata.emum";
import {
  DadataResponse,
  DadataSuggestion,
  DadataConfig,
  DadataConfigDefault
} from "./models/dadata.models";
import { DadataService } from "./services/dadata.service";

let uniqueDadataIdCounter = 0;

@Component({
  selector: 'mn-dadata',
  templateUrl: './dadata.component.html',
  styleUrls: [ './dadata.component.scss' ],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => DadataComponent),
    multi: true
  }]
})
export class DadataComponent implements OnInit, ControlValueAccessor, OnChanges {
  @ViewChild('inputValue', { static: true }) inputValue: ElementRef;

  @Input() config: DadataConfig = DadataConfigDefault;

  @Input() apiKey: string;
  @Input() disabled = false;
  @Input() type = DadataType.address;
  @Input() limit = DadataConfigDefault.limit;
  @Input() placeholder = '';
  @Input() locations = null;
  @Output() selectedSuggestion: DadataSuggestion;

  @Output() selected: EventEmitter<DadataSuggestion> = new EventEmitter<DadataSuggestion>();

  private v: any = '';
  private inputString$ = new Subject<string>();

  id = `dadata-${uniqueDadataIdCounter++}`;
  currentFocus = -1;
  opened = false;
  data: DadataSuggestion[] = [];

  onTouched = () => {};
  propagateChange: any = () => {};
  validateFn: any = () => {};

  constructor(
    private dataService: DadataService,
    private r: Renderer2,
    private elRef: ElementRef,
    @Inject(DOCUMENT) private document: Document,
  ) {
  }

  get value() {
    return this.v;
  }

  set value(v: any) {
    this.v = v;
    this.propagateChange(v);
  }

  ngOnInit(): void {
    this.type = this.config.type;
    this.locations = this.config.locations;
    this.dataService.setApiKey(this.apiKey ? this.apiKey : this.config.apiKey);
    this.inputString$.pipe(
      debounce(() => timer(this.config.delay ? this.config.delay : 500)),
    ).subscribe(x => {
      this.dataService.getData(x, this.type, this.config)
        .subscribe((y: DadataResponse) => {
        this.data = y.suggestions;
        if (this.data.length) {
          this.opened = true;
        }
      });
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    // if (changes) {
    //
    // }
  }

  getData(value: string) {
    this.inputString$.next(value);
    this.currentFocus = -1;
  }

  onClick(e: MouseEvent, item: DadataSuggestion) {
    this.inputValue.nativeElement.value = item.value;
    this.propagateChange(item.value);
    this.inputValue.nativeElement.focus();
    this.selectedSuggestion = item;
    this.data = [];
    this.currentFocus = -1;
    this.opened = false;
    this.selected.emit(item);
  }

  @HostListener('document:click', ['$event'])
  onOutsideClick($event: MouseEvent) {
    if (!this.opened) {
      return;
    }
    if (!this.elRef.nativeElement.contains($event.target)) {
      this.data = [];
      this.opened = false;
    }
  }

  setFocus(id: number) {
    const activeEl = this.document.getElementById(id + 'item');
    this.r.addClass(activeEl, 'active');
  }

  removeFocus(id: number) {
    if (id !== -1) {
      const activeEl = this.document.getElementById(id + 'item');
      this.r.removeClass(activeEl, 'active');
    }
  }

  onArrowDown() {
    this.removeFocus(this.currentFocus);
    if (this.currentFocus >= this.data.length - 1) {
      this.currentFocus = 0;
    } else {
      this.currentFocus++;
    }
    this.setFocus(this.currentFocus);
  }

  onArrowUp() {
    this.removeFocus(this.currentFocus);
    if (this.currentFocus === 0) {
      this.currentFocus = this.data.length - 1;
    } else {
      this.currentFocus--;
    }
    this.setFocus(this.currentFocus);
  }

  onEnter(event: KeyboardEvent) {
    this.selectedSuggestion = this.data[this.currentFocus];
    this.inputValue.nativeElement.value = this.selectedSuggestion.value;
    this.data = [];
    this.currentFocus = -1;
    this.propagateChange(this.selectedSuggestion.value);
    this.selected.emit(this.selectedSuggestion);
  }

  writeValue(value: any): void {
    if (value !== undefined && value !== null) {
      this.v = value;
    } else {
      this.v = '';
    }

    this.r.setProperty(this.inputValue.nativeElement, 'innerHTML', unwrapHtmlForSink(createHtml(this.v)));
  }

  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }
}
