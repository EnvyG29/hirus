------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Schema: core
-- Create: Date: 2019-11-25
------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------
-- Desc: Create core.projects Table
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."projects_id_seq" INCREMENT 1 START 1;
CREATE TABLE "core"."projects" (
     "id"                       INTEGER NOT NULL DEFAULT nextval('core.projects_id_seq'::REGCLASS)
    ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"cp_lkey"                  INTEGER NOT NULL DEFAULT 1
    ,"cp_rkey"                  INTEGER NOT NULL DEFAULT 2
    ,"cp_lvl"                   INTEGER NOT NULL DEFAULT 0
    ,"cp_meta"                  JSONB NOT NULL
    ,"cp_enable"                BOOLEAN NOT NULL DEFAULT TRUE
    ,PRIMARY KEY ("id")
);
ALTER SEQUENCE "core"."projects_id_seq" OWNED BY "core"."projects"."id";

-- Comment
COMMENT ON TABLE "core"."projects" IS 'Registred projects';
COMMENT ON COLUMN "core"."projects"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."projects"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."projects"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."projects"."cp_lkey" IS 'Record left key (Nested Sets)';
COMMENT ON COLUMN "core"."projects"."cp_rkey" IS 'Record right key (Nested Sets)';
COMMENT ON COLUMN "core"."projects"."cp_lvl" IS 'Record level (Nested Sets)';
COMMENT ON COLUMN "core"."projects"."cp_meta" IS 'Projects Information';
COMMENT ON COLUMN "core"."projects"."cp_enable" IS 'Enable|Disable projects';

/*
{
  "name": "Root",
  "desc": "Root Super Project",
  "icon": {
    "type": "fa",
    "val": ["fas", "project-diagram"]
  }
}
*/