import { UserProfile } from '../app/profile.model';
import { ApiResponse } from '../app/api-response.model';

export interface AuthState {
  handling: boolean;
  isLoggedIn: boolean;
  user?: UserProfile;
}

export interface AuthPayload {
  username: string;
  password: string;
}

export interface AuthResponse extends ApiResponse {
  data: any
}
