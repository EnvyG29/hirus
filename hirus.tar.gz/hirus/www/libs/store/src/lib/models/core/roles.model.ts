import { ApiResponse } from '@mn/store';
import { NestedItems } from '@mn/components/hchart';

export interface RoleAddEditPayload {
  id?: number;
  pid?: number;
  name: string;
  desc: string;
  icon: {
    type: 'fa' | 'img';
    font?: 'fas' | 'fab' | 'far';
    path?: string;
    iname?: string;
  };
}

export interface RoleItem extends NestedItems {
  meta: {
    name: string;
    desc: string;
    icon: {
      type: 'fa' | 'img',
      val: string[] | string;
    };
  };
  child?: RoleItem[];
}

export interface RoleResponse extends ApiResponse {
  data: RoleItem;
}
