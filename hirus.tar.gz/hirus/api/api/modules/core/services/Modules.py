import logging

from sqlalchemy import select
from sqlalchemy import delete
from sqlalchemy import and_
from sqlalchemy.ext.asyncio import AsyncSession

from ....common.exceptions.RaiseEx import RaiseEx

from ..schemas.Payloads import ProjectModulesChange as prModulesChange

from ..models.ProjectsModules import ProjectsModules as mProjectsModules
from ..models.ProjectModulesV import ProjectModulesV as mProjectModulesV

log = logging.getLogger('api.core.service.modules')

async def get_modules(pid: int, sess: AsyncSession):
    t_data = await sess.execute(
        select(mProjectModulesV)
        .filter(mProjectModulesV.cp_id == pid)
        .order_by(mProjectModulesV.id)
    )

    return t_data.scalars().all()

async def update_modules(req: prModulesChange, sess: AsyncSession):
    log.warning('Request => {}'.format(req))

    t_pm = await sess.execute(
        select(mProjectsModules)
        .filter(
            and_(
                mProjectsModules.cpm_cp_id == req.pid,
                mProjectsModules.cpm_cm_id == req.mid,
            )
        )
    )

    pm = t_pm.scalars().first()

    if pm is None and req.status is True:
        i_pm = mProjectsModules(
            cpm_cp_id=req.pid,
            cpm_cm_id=req.mid
        )
        sess.add(i_pm)
        return await sess.commit()

    if pm and req.status is False:
        await sess.execute(
            delete(mProjectsModules)
            .filter(
                mProjectsModules.id == pm.id
            )
        )
        return await sess.commit()

    raise RaiseEx(code=400, msg='Something Wrong. No data')
