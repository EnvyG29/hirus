## API

### Build Status
[![Build Status](https://ci.hirus.ru/api/badges/HiRus/api/status.svg)](https://ci.hirus.ru/HiRus/api)

### Api Server
The api server is generated from [FastAPI](https://fastapi.tiangolo.com/)

### Local Development

For local development

Run command

``docker-compose -f api-dev.yml up --build ``