import { AfterContentInit, Component, Input } from '@angular/core';
import { TabComponent } from './tab/tab.component';

@Component({
  selector: 'mn-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})
export class TabsComponent implements AfterContentInit {
  @Input() activeTab: string;
  tabs: TabComponent[] = [];

  ngAfterContentInit() {
    if (this.activeTab) {
      const tab = this.tabs.find((tab) => {
        return tab.tabId === this.activeTab
      });
      if (tab) {
        this.selectTab(tab);
      }
    }
  }

  addTab(tab: TabComponent) {
    if (this.tabs.length === 0) {
      tab.active = true;
    }

    this.tabs.push(tab);
  }

  selectTab(tab: TabComponent) {
    this.tabs.forEach((tab) => {
      tab.active = false;
    });

    tab.active = true;
  }
}
