export interface CarouselItem {
  bg: string;
  header: string;
  subheader?: string;
  content?: string[];
  button?: {
    label: string;
    action: string;
  };
}

export const carouselData: CarouselItem[] = [
    {
      bg: 'https://via.placeholder.com/1920x400.webp/f00/fff?text=Slide1',
      header: 'Слайд по умолчанию',
      content: ['Это пустой слайд по умолчанию.', 'Возможно, Вы забыли передать в него данные.']
    },
    {
      bg: 'https://via.placeholder.com/1920x400.webp/0f0/fff?text=Slide2',
      header: 'Слайд по умолчанию 2',
      content: ['Это пустой слайд по умолчанию.', 'Возможно, Вы забыли передать в него данные.']
    },
    {
      bg: 'https://via.placeholder.com/1920x400.webp/00f/fff?text=Slide3',
      header: 'Слайд по умолчанию 3',
      content: ['Это пустой слайд по умолчанию.', 'Возможно, Вы забыли передать в него данные.']
    }
  ];
