------------------------------------------------------------------------------------------------------------------------
-- Author: Semenets Pavel <darkman@meganet.ru>
-- Project: mn
-- Create: Date: 2018-11-12
-- Desc: Platform modules
------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------
-- Desc: Create core.modules table
------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE "core"."modules_id_seq" INCREMENT 1 START 1;

CREATE TABLE "core"."modules" (
     "id"                       INTEGER NOT NULL DEFAULT nextval('core.modules_id_seq'::REGCLASS)
    ,"create_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"update_at"                TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
    ,"cm_meta"                  JSONB NOT NULL DEFAULT '{}'
    ,PRIMARY KEY ("id")
);
ALTER SEQUENCE "core"."modules_id_seq" OWNED BY "core"."modules"."id";

-- Comment
COMMENT ON TABLE "core"."modules" IS 'Registred modules';
COMMENT ON COLUMN "core"."modules"."id" IS 'Primary Key (Sequence)';
COMMENT ON COLUMN "core"."modules"."create_at" IS 'Record create date';
COMMENT ON COLUMN "core"."modules"."update_at" IS 'Record update date';
COMMENT ON COLUMN "core"."modules"."cm_meta" IS 'Module Metadata';

/*
------------------------------------------------------------------------------------------------------------------------
-- Desc: cm_meta structure
------------------------------------------------------------------------------------------------------------------------
{
    "name": "Test",
    "desc": "Test Module",
    "mode": "dev|test|prod",
    "type": "public|private",
    "icon": {
        "type": "fa",
        "val": ["fas", "box-open"]
    },
    "menu": {
        "label": "Test 1",
        "url": "/test",
        "icon": {
            "type": "fa",
            "val": ["fab", "google"]
        },
        child?: []
    },
    "ctl": [{
        "name": "",
        "desc": "",
        "mask": "1-15"
    }],
    "active": "true|false",
    "managed": "true|false"
}

{
    "name": "vATS",
    "desc": "Virtual ATS",
    "mode": "dev",
    "type": "public",
    "icon": {
        "type": "fa",
        "val": ["fas", "asterisk"]
    },
    "menu": {},
    "ctl": [{
      "group": "Reports",
      "ctl": "ats_records_get",
      "desc": "Get Ats call records"
    }],
    "active": "true",
    "managed": "true"
}

{
    "name": "Mail",
    "desc": "Mail Server",
    "mode": "dev",
    "type": "public",
    "icon": {
        "type": "fa",
        "val": ["fas", "paper-plane"]
    },
    "menu": {},
    "ctl": [],
    "active": "true",
    "managed": "true"
}

{
    "name": "Hardware",
    "desc": "Hardware Inventory",
    "mode": "dev",
    "type": "public",
    "icon": {
        "type": "fa",
        "val": ["fas", "microchip"]
    },
    "menu": {},
    "ctl": [],
    "active": "true",
    "managed": "true"
}

{
  "name": "DNS",
  "desc": "Domain Name Server",
  "icon": {
    "val": ["fas", "atlas"],
    "type": "fa"
  },
  "menu": {},
  "ctl": [{
    "group": "Zones",
    "ctl": "dns_zones_get",
    "desc": "Get Dns Zone List"
  },{
    "group": "Records",
    "ctl": "dns_records_get",
    "desc": "Get Dns Zone Records"
  },{
    "group": "Records",
    "ctl": "dns_records_put",
    "desc": "Update Dns Zone Records"
  }],
  "mode": "dev",
  "type": "public",
  "active": "true",
  "managed": "true"
}

{
    "name": "Core",
    "desc": "Core Platform",
    "icon": {
        "type": "fa",
        "val": ["fas", "box-open"]
    },
    "menu": {},
    "ctl": [{
        "group": "Special",
        "ctl": "all",
        "desc": "Special Permission"
    },{
        "group": "Projects",
        "ctl": "projects_get",
        "desc": "Get projects list"
    },{
        "group": "Projects",
        "ctl": "projects_post",
        "desc": "Create project"
    },{
        "group": "Projects",
        "ctl": "projects_put",
        "desc": "Update project info"
    },{
        "group": "Projects",
        "ctl": "projects_delete",
        "desc": "Delete project"
    },{
        "group": "Roles",
        "ctl": "roles_get",
        "desc": "Get roles list"
    },{
        "group": "Roles",
        "ctl": "roles_post",
        "desc": "Create role"
    },{
        "group": "Roles",
        "ctl": "roles_put",
        "desc": "Update role info"
    },{
        "group": "Roles",
        "ctl": "roles_delete",
        "desc": "Delete Role"
    },{
        "group": "Modules",
        "ctl": "modules_get",
        "desc": "Get modules list"
    },{
        "group": "Modules",
        "ctl": "modules_put",
        "desc": "Modules enable/disable"
    }],
    "mode": "dev",
    "type": "public",
    "active": "true",
    "managed": "false"
}
*/
