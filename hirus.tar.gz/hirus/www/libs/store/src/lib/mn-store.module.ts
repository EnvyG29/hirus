import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { ActionReducerMap, MetaReducer } from '@ngrx/store';
import { environment } from '@mn/environments';

// import { uploadNode, uploadReducer } from "./reducers";

import { authNode, authReducer } from './reducers';
import { coreNode, coreReducer } from './reducers';

import {
  AuthState,
  CoreState,
//  UploadState
} from './models';

import { AuthEffects } from './effects/auth/auth.effects';
import { ModulesEffects } from './effects/core/modules.effects';
import { ProjectsEffects } from './effects/core/projects.effects';
import { RolesEffects } from './effects/core/roles.effects';
import { PermissionsEffects } from "./effects/core/permissions.effects";
import { WbEffects } from './effects/core/wb.effects';


export interface AppState {
  // [uploadNode]: UploadState;
  [authNode]: AuthState;
  [coreNode]: CoreState;
}

const reducers: ActionReducerMap<AppState> = {
  // [uploadNode]: uploadReducer,
  [authNode]: authReducer,
  [coreNode]: coreReducer,
};

const metaReducers: MetaReducer<AppState>[] = !environment.production ? [] : [];

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,

    StoreModule.forRoot(
      reducers,{
        metaReducers,
        runtimeChecks: {
          strictStateImmutability: true,
          strictActionImmutability: true
        },
      }
    ),
    EffectsModule.forRoot([
      AuthEffects,
      ModulesEffects,
      ProjectsEffects,
      RolesEffects,
      PermissionsEffects,
      WbEffects
    ]),
    !environment.production ? StoreDevtoolsModule.instrument() : [],
  ],
})
export class MnStoreModule {}
