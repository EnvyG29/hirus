import { Component, Input, OnInit } from '@angular/core';

import {
  CarouselItem,
  carouselData
} from './model/carousel.model';
import { transition, trigger, useAnimation } from '@angular/animations';
import { Router } from '@angular/router';
import { decrementAnimation, incrementAnimation } from './carousel.animations';

@Component({
  selector: 'mn-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss'],
  animations: [
    trigger('slide', [
      transition(':increment',
        useAnimation(incrementAnimation)
      ),
      transition(':decrement',
        useAnimation(decrementAnimation)
      )
    ])
  ]
})
export class CarouselComponent implements OnInit {
  @Input() slides: CarouselItem[] = [...carouselData];

  timer: any;

  slideDirection = 'stale';
  currentSlide = 0;
  transitionIndex = 0;

  constructor(public router: Router) {
  }

  ngOnInit() {
    this.start()
  }

  next() {
    if (this.slides.length > 1) {
      this.slideDirection = 'left';
      if (this.slides.length - 1 > this.currentSlide) {
        this.currentSlide = this.currentSlide + 1;
      } else {
        this.currentSlide = 0;
      }

      this.transitionIndex = this.transitionIndex + 1;
    }
  }

  previous() {
    if (this.slides.length > 1) {
      this.slideDirection = 'right';
      if (this.currentSlide === 0) {
        this.currentSlide = this.slides.length - 1;
      } else {
        this.currentSlide = this.currentSlide - 1;
      }

      this.transitionIndex = this.transitionIndex - 1;
    }
  }

  start() {
    if (this.slides.length > 1) {
      this.timer = setInterval(() => {
        this.next()
      }, 7000);
    }
  }

  stop() {
    clearInterval(this.timer);
  }

  move(addr: any) {
    if (addr) { this.router.navigate([addr]) }
  }
}
