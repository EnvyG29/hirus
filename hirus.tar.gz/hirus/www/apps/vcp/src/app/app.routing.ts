import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from '@mn/guards';

export const routes: Routes = [
  {
    path: '',
    canActivate: [AuthGuard],
    children: [
      {
         path: '', redirectTo: 'dash', pathMatch: 'full'
      },
      {
        path: 'dash',
        loadChildren: () => import('./modules/dash/dash.module').then((m) => m.DashModule),
        data: { breadcrumb: 'Dashboard' },
      }
    ]
  },
  {
    path: 'auth',
    loadChildren: () => import('./modules/auth/auth.module').then((m) => m.AuthModule),
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRouting {}
