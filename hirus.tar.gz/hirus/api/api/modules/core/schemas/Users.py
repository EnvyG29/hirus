# -*- coding: utf-8 -*-

from typing import List
from typing import Optional

from pydantic import Field
from pydantic import BaseModel
from pydantic import EmailStr

from ....common.schema.TblBase import TblBase
from ....common.schema.Response import SuccessResponse

class NameDict(BaseModel):
    first: Optional[str] = Field(None, description='First Name')
    sur: Optional[str] = Field(None, description='Sur Name')
    last: Optional[str] = Field(None, description='Last Name')

class TelDict(BaseModel):
    type: str
    num: str
    default: bool

class EmailDict(BaseModel):
    type: str
    email: EmailStr
    default: bool

class OauthDict(BaseModel):
    type: str
    enabled: bool

class Credentials(BaseModel):
    tel: str
    email: EmailStr
    login: Optional[str]

class Aditional(BaseModel):
    tel: List[Optional[TelDict]]
    email: List[Optional[EmailDict]]

class Profile(BaseModel):
    name: NameDict
    oauth: List[Optional[OauthDict]]
    aditional: Aditional

class CuProfile(BaseModel):
    balance: float
    profile: Profile
    credentials: Credentials

class UsersItem(TblBase):
    cu_profile: CuProfile
    cu_padm: bool = False
    cu_enable: bool = True

    class Config:
        orm_mode = True

class User(SuccessResponse):
    data: UsersItem

    class Config:
        arbitrary_types_allowed = True

class Users(SuccessResponse):
    data: List[UsersItem]

    class Config:
        arbitrary_types_allowed = True
